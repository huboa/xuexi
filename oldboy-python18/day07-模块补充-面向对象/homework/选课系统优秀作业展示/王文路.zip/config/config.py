# -*- coding:utf-8 -*-
import os,sys
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

ADMIN_DIR=os.path.join(BASE_DIR,'db','admin')
CLASS_DIR=os.path.join(BASE_DIR,'db','classes')
COURSE_DIR=os.path.join(BASE_DIR,'db','course')
STUDENT_DIR=os.path.join(BASE_DIR,'db','students_file')
TEACH_DIR=os.path.join(BASE_DIR,'db','teacher_file')
SCHOOL_DIR=os.path.join(BASE_DIR,'db','schools')
TEACHER_COURSE_DIR=os.path.join(BASE_DIR,'db','teacher_course')