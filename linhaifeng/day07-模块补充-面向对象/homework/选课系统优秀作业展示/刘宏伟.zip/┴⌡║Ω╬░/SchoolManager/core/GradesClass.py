#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/17 0017 14:20
# @Author  : LiuHongWei
# @Site    : 
# @File    : GradesClass.py
# @Software: PyCharm
from .ReadDb import ReadDb
class Greades(ReadDb):
    def __init__(self,gread_name,course_name,teacher_name):
        self.gread_name = gread_name
        self.course_name = course_name
        self.teacher_name = teacher_name
        self.student_list ={}

        # 读取班级数据
        grade_list = self.readGradeDb()
        grade_list[self.gread_name] = self
        # 存储班级数据
        self.writeGradeDb(grade_list)


