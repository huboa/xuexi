# -*- coding:utf-8 -*-
from core import common,menu
from config import config
from modules import Class
from modules.Handle import Handle
def handle_func():
    return {
        'a':Handle.create_school,
        'b':Handle.create_class,
        'c':Handle.create_teacher,
        'd':Handle.create_course,
        'e':Handle.create_student,
        'g':Handle.select_school,
        'h':Handle.select_class,
        'i':Handle.select_teacher,
        'j':Handle.select_course,
        'k':Handle.select_student,
        'm':Handle.create_relation,
        'n':Handle.select_relation,
    }
def run():
    if common.is_exists(config.ADMIN_DIR):
        common.printf('开始加载数据','correct')
        try:
            user = input('注册管理员用户名：').strip()
            pwd = input('注册管理员密码：').strip()
            obj = Class.Admin(user, pwd)
            obj.save()
        except Exception as e:
            print(e)
    while True:
        common.printf(' 管理员登录 '.center(40,'/'), 'correct')
        username = input('用户名[q:exit]：').strip()
        if username == 'q':break
        if not username:continue
        password = input('密码：').strip()
        user_info = Class.Admin.login(username,password)
        if user_info['flag']:
            common.printf(user_info['data'],'correct')
            while True:
                menu.admin_menu(username)
                common.printf('【提示】请在添加班级前创建课程关联')
                choice = input('请选择服务编号：').strip()
                if not choice:continue
                if choice == 'f':break
                if choice in handle_func():
                    handle_func()[choice]()
                else:
                    common.printf('服务不存在','error')
        else:
            print('用户名或密码错误请重输入')
