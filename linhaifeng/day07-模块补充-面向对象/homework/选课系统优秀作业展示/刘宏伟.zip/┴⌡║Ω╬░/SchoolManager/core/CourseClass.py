#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/16 0016 16:30
# @Author  : LiuHongWei
# @Site    : 
# @File    : CourseClass.py
# @Software: PyCharm
from .ReadDb import ReadDb
class Course(ReadDb):
    def __init__(self,name,class_cycle,class_price,school_name):
        self.name = name
        self.cycle = class_cycle
        self.price = class_price
        self.school_name = school_name

        # 读取课程数据
        course_list=self.readCourseDb()
        course_list[self.name] = self
        # 存储课程数据
        self.writeCourseDb(course_list)
