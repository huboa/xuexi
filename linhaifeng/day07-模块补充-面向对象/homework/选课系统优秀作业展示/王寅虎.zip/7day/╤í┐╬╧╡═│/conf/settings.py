#_*_coding:utf-8_*_
import os
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCHOOL_PATH=os.path.join(BASE_DIR,'db','school')