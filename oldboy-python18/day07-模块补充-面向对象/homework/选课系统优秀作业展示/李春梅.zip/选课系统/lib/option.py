#_*_coding:utf-8_*_
__author__='seagull'
import os
import time
from conf.profile import *
import logging
from  conf.logging_tem import *
logger = logging.getLogger(__name__)
option1=[
    '添加',
    '查看',
    '删除',
    '退出'
]

option2=[
    '学校',
    '学员',
    '讲师',
    '课程',
    '班级',
    '返回'
]

option3={
    '查看':['选课信息','本人信息'],
    '选课':None,
    '签到':None,
    '提交作业':None,
    '退出':None
}
option=[
    '查看学生信息：',
    '批改作业',
    '打成绩',
    '退出'
]


currunt=[]
def auth(func):
    def wapper(*args,**kwargs):
        while True:
            username=input('请输入用户名：')
            userpass=input('请输入密码：')
            for n in os.walk(PATH_INFO):
                if username not in n[2]:
                    print('用户名不存在！')
                    continue
                path=os.path.join(PATH_INFO,username)
                with open(path,'r') as f_r:
                    line=eval(f_r.read())
                    if userpass != line['passwd']:
                        print('密码错误！')
                        continue
                    currunt.append(username)
                    info_log = '%s\n%s log in .....\n' % (time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), currunt)
                    logging_info(info_log)
                    res=func(*args,**kwargs)
                    return res
    return wapper


def demo():
    logger.debug("start range... time:{}".format(time.time()))
    logger.info("=================")
    for i in range(10):
        logger.debug("i:{}".format(i))
        time.sleep(0.2)
    else:
        logger.debug("over range... time:{}".format(time.time()))
    logger.info("==============")


def logging_info(info_log):
    path = os.path.join(BASE_DIR,'log','access.log')
    if os.path.exists(path):
        with open(path,'a',encoding='utf-8') as f_a:
            f_a.write(info_log)
    else:
        with open(path,'w',encoding='utf-8') as f_a:
            f_a.write(info_log)






