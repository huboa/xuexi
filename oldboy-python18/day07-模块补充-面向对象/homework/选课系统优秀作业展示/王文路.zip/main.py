# -*- coding:utf-8 -*-
import sys,os
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
sys.path.append(BASE_DIR)
from bin import start
if __name__ == '__main__':
    exa = start.Entrance()
    exa.enter()