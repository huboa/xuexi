#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/17 0017 13:45
# @Author  : LiuHongWei
# @Site    : 
# @File    : main.py
# @Software: PyCharm
from .StudentClass import StudentClass
from .CourseClass import Course
from .GradesClass import Greades
from .ReadDb import ReadDb
from .SchoolClass import School
from .StudentClass import StudentClass
from .TeacherClass import Teacher
from conf.setting import *
def main():
    while True:
        for i, value in main_dic.items():
            print(i, value)
        num = input('请选择您要进入的系统序号：')
        if num in main_dic:
            # 选1为管理员系统
            if num == '1':
                admin= input('请输入管理员姓名：')
                admin_pass = input('请输入管理员密码')
                if admin  == 'admin' and admin_pass == '123':
                    while True:
                        # 打印管理员菜单
                        for i, value in master_dic.items():
                            print(i, value)
                        num = input('请选择您要进入的系统序号：')
                        # 创建学校
                        if  num in master_dic and num == '1':
                            school_name = input('请输入学校名称：')
                            School(school_name)
                            print('创建学校成功')
                            print('返回主菜单')
                            continue
                        # 创建教师
                        elif num in master_dic and num == '2':
                            school_all = ReadDb.readSchoolDb()
                            while True:
                                print('请选择您的学校：')
                                for i in school_all:
                                    print(i)
                                school_name = input('请输入选择的学校名称：')
                                if school_name in school_all:
                                    school_obj = school_all[school_name]
                                    school_obj.createTeacher()
                                    print('返回主菜单')
                                    break
                                else:
                                    print('输入有误请重新输入')
                                    continue
                        # 创建课程
                        elif num in master_dic and num == '3':
                            school_all = ReadDb.readSchoolDb()
                            while True:
                                print('请选择您的学校：')
                                for i in school_all:
                                    print(i)
                                school_name = input('请输入选择的学校名称：')
                                if school_name in school_all:
                                    school_obj = school_all[school_name]
                                    school_obj.createCourse()
                                    print('返回主菜单')
                                    break
                                else:
                                    print('输入有误请重新输入')
                                    continue
                        # 创建班级
                        elif num in master_dic and num == '4':
                            school_all = ReadDb.readSchoolDb()
                            while True:
                                print('请选择您的学校：')
                                for i in school_all:
                                    print(i)
                                school_name = input('请输入选择的学校名称：')
                                if school_name in school_all:
                                    school_obj = school_all[school_name]
                                    school_obj.createGrades()
                                    print('返回主菜单')
                                    break
                                else:
                                    print('输入有误请重新输入')
                                    continue
                        elif num in master_dic and num == '5':
                            break
                        else:
                            print('输入有误请重新输入')
                            continue
                else:
                    print('用户名密码错误')
                    continue
            # 选2为学生系统
            elif num == '2':
                while True:
                    for i,value in student_main.items():
                        print(i,value)
                    task = input('请选择要进入的功能序号：')
                    if task in student_main and task == '1':
                        school_all = ReadDb.readSchoolDb()
                        while True:
                            print('请选择您的学校：')
                            for i in school_all:
                                print(i)
                            school_name = input('请输入选择的学校名称：')
                            if school_name in school_all:
                                school_obj = school_all[school_name]
                                school_obj.createStudent()
                                print('返回主菜单')
                                break
                            else:
                                print('输入有误请重新输入')
                                continue
                    elif task in student_main and task == '2':
                        student_obj = StudentClass.login()
                        if student_obj:
                            while True:
                                for num,v in student_dic.items():
                                    print(num,v)
                                task = input('请选择要进入的功能序号：')
                                # 展示本人详情
                                if task in student_dic and task == '1':
                                    student_obj.showInfo()
                                # 进行支付学费
                                elif task in student_dic and task == '2':
                                    student_obj.payTuition()
                                # 进行提交作业
                                elif task in student_dic and task == '3':
                                    student_obj.submitTask()
                                # 退出
                                elif task in student_dic and task == '4':
                                    break
                                else:
                                    print('输入有误请重新输入')
                                    continue
                    elif task in student_main and task == '3':
                        break
                    else:
                            print('登录失败:')
                            continue
            # 选3为教师系统
            elif num == '3':
                teacher_obj = Teacher.login()
                if teacher_obj:
                    while True:
                        for tid, tv in teacher_dic.items():
                            print(tid, tv)
                        task = input('请选择要进入的功能序号：')
                        if task in teacher_dic and task == '1':
                            teacher_obj.showInfo()
                        elif task in teacher_dic and task == '2':
                            teacher_obj.showGradeInfo()
                        elif task in teacher_dic and task == '3':
                            teacher_obj.createClassRecord()
                        elif task in teacher_dic and task == '4':
                            teacher_obj.changeSore()
                        elif task in teacher_dic and task == '5':
                            break
                        else:
                            print('输入有误请重新输入')
                            continue
                    else:
                        print('登录失败:')
                        continue
            elif num == '4':
                exit()
        else:
            print('您输入有误：')

