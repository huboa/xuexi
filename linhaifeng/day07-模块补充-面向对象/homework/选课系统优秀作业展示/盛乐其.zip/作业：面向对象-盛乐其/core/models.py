#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/13 18:20
# @Author  : ShengLeQi
from lib import common
from conf import settings
import  os
import random
import pickle
import time
class Base:
    def save(self):
        file_path=r'%s/%s' %(self.DB_PATH,self.id)
        pickle.dump(self,open(file_path,'wb'))
    @classmethod
    def get_obj_by_id(cls,id):
        file_path=r'%s/%s' %(cls.DB_PATH,id)
        return pickle.load(open(file_path,'rb'))
    @classmethod
    def get_all(cls,DB_PATH):
        school_l=[]
        records = (cls.get_obj_by_id(id) for id in os.listdir(DB_PATH))
        for school in records:
            if school:school_l.append(school)
        return school_l

class School(Base):
    '''名字、地址、城市'''
    DB_PATH = settings.SCHOOL_PATH
    def __init__(self,name,address):
        self.id = common.create_id()
        self.name=name
        self.address=address
        self.classes=[]
        self.teacher=[]
        self.student=[]

class Course(Base):
    '''名字、价格、周期'''
    DB_PATH = settings.COURSE_PATH
    def __init__(self,name,price,period):
        self.id = common.create_id()
        self.name=name
        self.price=price
        self.period=period

class Classes(Base):
    '''班级类，包含名称，学期、开课时间，讲师'''
    DB_PATH = settings.CLASSES_PATH
    def __init__(self,name,semester,date):
        self.id = common.create_id()
        self.name=name
        self.semester=semester
        self.date=date
        self.teacher=[]
        self.student=[]
        self.course=[]

class ClassRecord(Base):
    def __init__(self,c_class,section,class_time):
        self.c_class=c_class
        self.section=section
        self.class_time=class_time

class Teacher(Base):
    '''讲师类，定义teacher_name，teacher_salary，包含teacher_class'''
    DB_PATH = settings.TEACHER_PATH
    def __init__(self,name,salary):
        self.id = common.create_id()
        self.name=name
        self.salary=salary
        self.classes=[]
        self.crouse=[]

class Student(Base):
    DB_PATH = settings.STUDENT_PATH
    def __init__(self,name,age):
        self.id = common.create_id()
        self.name=name
        self.age=age
        self.classes=[]
        self.course=[]

class StudyRecord(Base):
    def __init__(self,class_record,status,date,achievement):
        self.id=common.create_id()
        self.class_record=class_record
        self.status=status
        self.date=date
        self.achievement=achievement
        self.sub_time=time.strftime('%Y-%m-%d %X')
    @classmethod
    def get_obj_by_phone(cls,phone):
        records=(cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            customer_obj=Student.get_obj_by_id(record.customer_id)
            if phone == customer_obj.phone:
                return record

# Shanghai=School('上海','上海浦东')
# Beijing=School('北京','北京沙河')
#
# # #创建课程
# Python=Crouse('Python',9999,'5mons')
# Linux=Crouse('Linux',15800,'6mons')
# Go=Crouse('Go',8000,'7mons',)

# #创建班级
python_18=Classes('python周末18期','2017-08-08','egg')
# python_7=Classes('python脱产7期',1,Python,'2017-08-09','Alex')
# Linux_35=Classes('linux架构35期',1,Linux,'2017-08-09','oldboy')












