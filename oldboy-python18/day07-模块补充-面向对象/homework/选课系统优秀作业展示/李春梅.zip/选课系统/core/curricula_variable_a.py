#_*_coding:utf-8_*_
__author__='seagull'
'''
administrator
'''
import os
from  lib.option import *
from  conf.profile  import *
import logging
from  conf.logging_tem import *
logger = logging.getLogger(__name__)
def auth_admin():
    for n in option1:
        print(option1.index(n),n)
    def option_judge():
        for n in option2:
            print(option2.index(n), n)
    judge=input('请选择：')
    if not judge.isdigit():auth_admin()
    judge=int(judge)
    if judge == 0:
        def judge_in():
            option_judge()
            judge = input('请选择添加对象：')
            if not judge.isdigit(): judge_in()
            judge = int(judge)
            if judge==0:
                school_name = input('请输入学校名字：')
                school_address = input('请输入学校地址：')
                path_school=os.path.join(PATH_SCHOOL,school_name)
                with open(path_school,'w+',encoding='utf-8') as f_school:
                    f_school.write('{"name":"%s",\n"address":"%s"}'
                                   %(school_name,school_address))
                judge_in()
            elif judge==1:
                def student():
                    name = input('请输入用户名：')
                    age = input('请输入年龄：')
                    passwd = input('请输入密码：')
                    student_pass = input('请再次输入密码：')
                    if passwd != student_pass:
                        print('两次输入密码不一样，请再次输入！')
                        student()
                    path_student = os.path.join(PATH_STUDENT, name)
                    path_info = os.path.join(PATH_INFO, name)
                    def tale_info(name,passwd):
                        with open(path_student, 'w+', encoding='utf-8') as f_student1,\
                            open(path_info,'w+',encoding='utf-8') as f_info:
                            f_student1.write('{"name":"%s",\n"age":%s,\n"teacher":[],\n"classes":[],\n"course":[],'
                                             '\n"school":[],\n"other":[]}'
                                           % (name,age))
                            f_info.write('{"name":"%s",\n"passwd":"%s"}'
                                         %(name,passwd))
                    tale_info(name,passwd)
                student()
                judge_in()
            elif judge==2:
                def teacher():
                    name = input('请输入讲师名：')
                    passwd = input('请输入密码：')
                    teacher_pass = input('请再次输入密码：')
                    if passwd != teacher_pass:
                        print('两次输入密码不一样，请再次输入！')
                        teacher()
                    path_teacher = os.path.join(PATH_TEACHER, name)
                    path_info = os.path.join(PATH_INFO, name)

                    def tale_info(name, passwd):
                        with open(path_teacher, 'w+', encoding='utf-8') as f_student1, \
                                open(path_info, 'w+', encoding='utf-8') as f_info:
                            f_student1.write('{"name":"%s"}'
                                             % (name))
                            f_info.write('{"name":"%s",\n"passwd":"%s"}'
                                         % (name, passwd))

                    tale_info(name, passwd)

                teacher()
                judge_in()
            elif judge == 3:
                def teache_info():
                    for n in os.walk(PATH_TEACHER):
                        for i in n[2]:
                            print(i,end='\n')
                        course=input('请输入添加的课程：')
                        price = input('请输入价钱：')
                        cycle = input('请输入课程周期：')
                        outine=input('课程大纲：')
                        path1 = os.path.join(PATH_COURSE, course)
                        with  open(path1, 'w', encoding='utf-8') as f_c:
                            f_c.write('{"name":"%s",\n"price":"%s",\n"cycle":"%s",\n"outline":"%s"}'
                                      %(course,price,cycle,outine))

                teache_info()

                judge_in()

            elif judge == 4:
                def teache_info():
                    for n in os.walk(PATH_CLASSES):
                        for i in n[2]:
                            print(i, end='\n')
                        classes = input('请输入添加的班级：')
                        term = input('请输入学期：')
                        course = input('请输入课程：')
                        start_data = input('开始日期：')
                        teacher_judge = input('请选择讲师：')
                        path1 = os.path.join(PATH_CLASSES, classes)
                        with  open(path1, 'w', encoding='utf-8') as f_c:
                            f_c.write('{"name":"%s",\n"term":"%s",\n"course":"%s",\n"start_data":"%s",\n"teacher":"%s"}'
                                      % (classes,term,course,start_data,teacher_judge))

                teache_info()

                judge_in()
            elif judge == 5:
                auth_admin()
            else:
                print('输入错误！')
                judge_in()
        judge_in()
    elif judge == 1:
        def judge_in():
            option_judge()
            judge = input('请选择查看对象：')
            if not judge.isdigit(): judge_in()
            judge = int(judge)
            def read_info(path,info):
                for n in os.walk(path):
                    for i in n[2]:
                        path1 = os.path.join(path, i)
                        with open(path1, 'r', encoding='utf-8') as f_r:
                            print('%s：%s\n' % (info,i), f_r.read())
                judge_in()
            if judge==0:
                read_info(PATH_SCHOOL,'学校')
            elif judge==1:
                read_info(PATH_STUDENT,'学员')
            elif judge==2:
                read_info(PATH_TEACHER,'讲师')
            elif judge==3:
                read_info(PATH_COURSE, '课程')
            elif judge == 4:
                read_info(PATH_CLASSES, '课程')
            elif judge == 5:auth_admin()
            else:judge_in()
        judge_in()
    elif judge==2:
        def judge_in():
            option_judge()
            judge = input('请选择删除对象：')
            if not judge.isdigit(): judge_in()
            judge = int(judge)
            def read_info(path, info):
                for n in os.walk(path):
                    for i in n[2]:
                       print(i)
                judge_del=input('请选择要删除的%s：'%info)
                if judge_del not in n[2]:
                    print('%s不存在！'%info)
                    judge_in()
                path_del=os.path.join(path,judge_del)
                os.remove(path_del)
                for info in os.walk(PATH_INFO):
                    if judge_del in info:
                        path_del = os.path.join(PATH_INFO, judge_del)
                        os.remove(path_del)
                judge_in()
            if judge == 0:
                read_info(PATH_SCHOOL, '学校')
            elif judge == 1:
                read_info(PATH_STUDENT, '学员')
            elif judge == 2:
                read_info(PATH_TEACHER, '讲师')
            elif judge == 3:
                for n in os.walk(PATH_TEACHER):
                    for i in n[2]:
                       print(i)
                teacher_del=input('请选择要删除课程的讲师：')
                if teacher_del not in n[2]:
                    print('%s不存在！'%teacher_del)
                    judge_in()
                path_del=os.path.join(PATH_TEACHER,teacher_del)
                with open(path_del, 'r', encoding='utf-8') as f_teacher_r:
                    f_r = eval(f_teacher_r.read())
                print(f_r)
                course = input('请输入要删除的课程:')
                with  open(path_del, 'w', encoding='utf-8') as f_teacher_w:
                    f_r['course'].remove(course)
                    f_teacher_w.write('%s' % f_r)
                for info in os.walk(PATH_COURSE):
                    if course in info:
                        path_del = os.path.join(PATH_COURSE, course)
                        os.remove(path_del)
                judge_in()
            elif judge == 4:
                read_info(PATH_COURSE, '班级')

            elif judge == 5:auth_admin()
            else:
                judge_in()
        judge_in()
    elif judge==3:exit()
    else:auth_admin()





















