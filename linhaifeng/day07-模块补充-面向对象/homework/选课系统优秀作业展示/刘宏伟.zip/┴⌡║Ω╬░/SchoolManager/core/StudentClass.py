#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/16 0016 16:49
# @Author  : LiuHongWei
# @Site    : 
# @File    : StudentClass.py
# @Software: PyCharm
import time
from .SchoolPeopleBase import SchoolPeople
from .ReadDb import ReadDb
class StudentClass(SchoolPeople,ReadDb):

    def __init__(self,name,pass_word,age,sex,class_name,course_name,school_name,tuition,is_pay=0):
        super().__init__(name,pass_word,age,sex)
        self.class_name = class_name
        self.tuition = tuition
        self.is_pay = is_pay
        self.submit_task = {}
        self.course_name = course_name
        self.school_name = school_name

        # 读取学生数据
        student_list = self.readStudentDb()
        student_list[self.name] = self
        # 存储学生数据
        self.writeStudentDb(student_list)
    def payTuition(self):
        '''支付学费方法'''
        if self.is_pay == 1:
            print("您当前学费已交不需要重复交纳学费")
        else:
            print("您当前需要付学费：",self.tuition,'元')
            while True:
                tuition = input("请输入您要付的学费需一次性付清：").strip()
                if tuition.isdigit() and (int(tuition) - int(self.tuition) == 0):
                    print('您已交完所有学费，谢谢')
                    self.is_pay = 1
                    # 写入学生db
                    student_info = self.readSchoolDb()
                    student_info[self.name] = self
                    self.writeStudentDb(student_info)
                    return True
                else:
                    print("您输入的有问题，请重新输入：")
                    continue

    def submitTask(self):
        '''提交作业方法'''
        task_name = input('请输入您要交的作业名称：').strip()
        print("恭喜您已作业已提交完成")
        self.submit_task[task_name] = 0

        student_info = self.readStudentDb()
        student_info[self.name] = self
        self.writeStudentDb(student_info)

    def showInfo(self):
        '''展示个人信息'''
        print('您的详细信息如下：')
        print('姓名：',self.name)
        print('年龄：',self.sex)
        print('所在学校：',self.school_name)
        print('所在班级：',self.class_name)
        print('所学课程：',self.course_name)
        print('学费：',self.tuition)
        if self.is_pay == 1:
            print('学费已交')
        else:
            print('学费未交')
        print('作业评分如下：')
        for name,score in self.submit_task.items():
            print('作业',name,'分数',score)
        print('*'*16)
    @staticmethod
    def login():
        student_all = ReadDb.readStudentDb()
        name = input('请输入您的姓名：')
        if name in student_all:
            studnet_info = student_all[name]
            pass_word = input('请输入您的密码：')
            if pass_word == studnet_info.pass_word:
                print('登录成功')
                return studnet_info
            else:
                print('您输入的密码有误')
                return False
        else:
            print("您输入的姓名有误")
            return False


