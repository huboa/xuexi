# -*- coding: utf-8 -*-
# @Author  : ShengLeQi
from core import models
from conf import settings
import sys,time,os

dic_teacher={}
def teacher_route(name):
    def deco(func):
        dic_teacher[name]=func
    return deco

@teacher_route('1')
def cat_students(Teacher):
    print('显示学生')

#查看班级
@teacher_route('2')
def  cat_classes():
    print('查看班级')

@teacher_route('3')
def create_class_record():
    print('查看。。。')

def run():
    print('输入讲师名字：默认Alex')
    Alex = models.Teacher('alex', 8888)
    Teacher = Alex
    while True:
        s_msg = '''
    -----------------------选项--------------------------------
                    1 查看学生列表
                    2 查看班级
                    3 查看。。。
                    0 退出
    -----------------------------------------------------------
                    '''
        print(s_msg)
        chice = input('选择 >').strip()
        if chice.isdigit() and int(chice) > 0 and int(chice) < 4:
            dic_teacher[chice](Teacher)
        elif chice.isdigit() and int(chice) == 0:
            break