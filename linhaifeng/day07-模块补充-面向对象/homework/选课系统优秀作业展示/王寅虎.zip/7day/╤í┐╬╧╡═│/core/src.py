#_*_coding:utf-8_*_
from core import school
import sys
import os
import pickle
func_dic={}
def make_route(name):
    def deco(func):
        func_dic[name]=func
    return deco
    print(deco)


@make_route('1')
def s_add():
    '''创建学校'''
    print('\033[45m开始创建学校\033[0m')
    while True:
        schoolname=input('学校名称: ')
        address=input('地址: ')
        city=input('城市: ')
        record=school.school_add.get_obj_by_schoolname(schoolname)
        if record:
            print('学校名称重复')
            return
        if all([schoolname,address,city]):
            school1 = school.school_add(schoolname, address, city)  # 创建学校
            school1.save()
            print('\033[45m学校创建成功\033[0m')
            break
        else:
            print('所有信息不能为空')

@make_route('2')
def school_sql():
    '''查看学校'''
    BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DB_PATH =os.path.join(BASE_DIR,'db','school')
    for id in os.listdir(DB_PATH):
        file_path=r'%s/%s' %(DB_PATH,id)
        f=pickle.load(open(file_path,'rb'))
        print('学校名称：%s  地址：%s  城市：%s' %(f.schoolname,f.address,f.city))

@make_route('3')
def course_add():
    '''创建课程'''
    print('\033[45m开始创建课程\033[0m')
    while True:
        coursename = input('课程名称: ')
        price = input('课程价格: ')
        outline = input('课程描述: ')
        schoolname = input('所属学校: ')
        record = school.course_add.get_obj_by_coursename(coursename)
        if record:
            print('课程名称重复')
            return
        record = school.school_add.get_obj_by_schoolname(schoolname)
        if record is None:
            print('学校不存在！')
            return
        if all([coursename,price,outline,schoolname]):
            course = school.course_add(coursename, price, outline, schoolname)  # 创建学校
            course.save()
            print('\033[45m课程创建成功\033[0m')
            break
        else:
            print('所有信息不能为空')
@make_route('4')
def course_sql():
    '''查看课程'''
    BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DB_PATH =os.path.join(BASE_DIR,'db','course')
    for id in os.listdir(DB_PATH):
        file_path=r'%s/%s' %(DB_PATH,id)
        s=pickle.load(open(file_path,'rb'))
        print('课程名称：%s  课程价格：%s  课程描述：%s   所在学校：%s' %(s.coursename,s.price,s.outline,s.schoolname))

@make_route('5')
def teacher_add():
    '''创建老师'''
    print('\033[45m开始创建老师\033[0m')
    while True:
        teachername = input('老师名称: ')
        age = input('年龄: ')
        sex = input('性别: ')
        schoolname = input('所属学校: ')
        record = school.teacher_add.get_obj_by_teachername(teachername)
        if record:
            print('老师名称重复')
            return
        record = school.school_add.get_obj_by_schoolname(schoolname)
        if record is None:
            print('学校不存在！')
            return
        if all([teachername,age,sex,schoolname]):
            course = school.teacher_add(teachername,age,sex,schoolname)  # 创建老师
            course.save()
            print('\033[45m老师创建成功\033[0m')
            break
        else:
            print('所有信息不能为空')
@make_route('6')
def teacher_sql():
    '''查看所有老师信息'''
    BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DB_PATH =os.path.join(BASE_DIR,'db','teacher')
    for id in os.listdir(DB_PATH):
        file_path=r'%s/%s' %(DB_PATH,id)
        t=pickle.load(open(file_path,'rb'))
        print('老师名称：%s  年龄：%s  性别：%s  所在学校：%s' %(t.teachername,t.age,t.sex,t.schoolname))

@make_route('7')
def class_add():
    '''创建班级'''
    print('\033[45m开始创建班级\033[0m')
    while True:
        classname = input('班级名称: ')
        Semester = input('学期名称: ')
        coursename = input('课程名称: ')
        schoolname = input('所属学校: ')
        teachername = input('任课教师: ')
        record = school.class_add.get_obj_by_classname(classname)  #判断班级名称是否重复
        if record:
            print('班级名称重复')
            return
        record = school.school_add.get_obj_by_schoolname(schoolname)  # 判断所属学校是否存在
        if record is None:
            print('学校不存在！')
            return
        record = school.teacher_add.get_obj_by_teachername(teachername) # 判断任教老师是否存在
        if record is None:
            print('老师不存在！')
            return
        record = school.teacher_add.get_obj_by_teachername(teachername)
        if  record.schoolname != schoolname:  # 判断学校是不是老师所在学校？
            print("输入学校错误或者任课老师不属于此学校！")
            return
        if all([classname, Semester,coursename, schoolname,teachername]):
            course = school.class_add(classname, Semester,coursename, schoolname,teachername)  # 创建班级
            course.save()
            print('\033[45m老师创建成功\033[0m')
            break
        else:
            print('所有信息不能为空')
@make_route('8')
def class_sql():
    '''查看所有老师信息'''
    BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DB_PATH =os.path.join(BASE_DIR,'db','class')
    for id in os.listdir(DB_PATH):
        file_path=r'%s/%s' %(DB_PATH,id)
        c=pickle.load(open(file_path,'rb'))
        print('班级名称：%s  学期名称：%s  课程名称：%s  所属学校：%s  任教老师：%s' %(c.classname,c.Semester,c.coursename,c.schoolname,c.teachername))

@make_route('9')
def student_add():
    '''创建学生'''
    print('\033[45m开始创建学生\033[0m')
    while True:
        studentname = input('学生名称: ')
        age = input('年龄: ')
        sex = input('性别: ')
        classname = input('所在班级: ')
        record = school.student_add.get_obj_by_studentname(studentname)  #判断学生是否存在
        if record:
            print('学生已存在')
            return
        record = school.class_add.get_obj_by_classname(classname)  #判断班级是否正确
        if record is None:
            print('班级不存在！')
            return
        if all([studentname,age,sex, classname]):
            course = school.student_add(studentname,age,sex,classname)  # 创建学生
            course.save()
            print('\033[45m学生创建成功\033[0m')
            break
        else:
            print('所有信息不能为空')
@make_route('10')
def student_sql():
    '''查看所有学生信息'''
    BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DB_PATH =os.path.join(BASE_DIR,'db','student')
    for id in os.listdir(DB_PATH):
        file_path=r'%s/%s' %(DB_PATH,id)
        st = pickle.load(open(file_path,'rb'))
        print('学生名称：%s  年龄：%s  性别：%s  所在班级：%s' %(st.studentname,st.age,st.sex,st.classname))


@make_route('11')
def classrecord_add():
    '''创建课堂记录'''
    print('\033[45m开始创建课堂记录\033[0m')
    while True:
        classrecordname = input('课堂记录名称: ')
        classrecordnum = input('第几级课: ')
        classname = input('所在班级: ')
        classrecorddata = input('课堂时间: ')
        record = school.classrecord_add.get_obj_by_classrecordname(classrecordname)  # 判断课堂记录是否存在
        if record:
            print('课堂记录名称已存在')
            return
        record = school.class_add.get_obj_by_classname(classname)  # 判断班级存在
        if record is None:
            print('班级不存在！')
            return
        if all([classrecordname, classrecordnum, classname]):
            course = school.classrecord_add(classrecordname, classrecordnum, classname)  # 创建课堂记录
            course.save()
            print('\033[45m课堂记录创建成功\033[0m')
            break
        else:
            print('所有信息不能为空')

@make_route('12')
def classrecord_sql():
    '''查看所有上课记录'''
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DB_PATH = os.path.join(BASE_DIR, 'db', 'classrecord')
    for id in os.listdir(DB_PATH):
        file_path = r'%s/%s' % (DB_PATH, id)
        cc = pickle.load(open(file_path, 'rb'))
        print('上课名称：%s  第几课：%s  班级：%s  上课时间：%s' % (cc.classrecordname, cc.classrecordnum, cc.classname, cc.classrecorddata))

@make_route('13')
def studyrecord_add():
    '''创建学习记录'''
    print('\033[45m开始创建学习记录\033[0m')
    while True:
        classrecordname = input('课堂信息名称: ')
        studyrename  = input('学生名称: ')
        studyrecordstate = input('签到状态 "Y" no "N": ')
        studyrecorddata = input('签到时间: ')
        studyrecordgrade = input('本次成绩：')
        record = school.classrecord_add.get_obj_by_classrecordname(classrecordname)  # 判断学生是否存在
        if record is None:
            print('课堂记录不存在！')
            return
        record = school.student_add.get_obj_by_studentname(studyrename)  # 判断学生是否存在
        if record is None:
            print('学生不存在！')
            return
        record = school.studyrecord_add.get_obj_by_studyrecordname(classrecordname,studyrename)  # 判断学生 学习记录是否重复
        if record:
            print('本次课程 此学生 学习记录已存在！')
            return
        if all([classrecordname,studyrename, studyrecordstate, studyrecorddata,studyrecordgrade]):
            course = school.studyrecord_add(classrecordname,studyrename, studyrecordstate, studyrecorddata,studyrecordgrade)  # 创建学生 学习记录
            course.save()
            print('\033[45m学习记录创建成功\033[0m')
            break
        else:
            print('所有信息不能为空')

@make_route('14')
def classrecord_sql():
    '''查看所有学校记录'''
    studyrename = input('请输入需要查询学习成绩的学生名称：')
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DB_PATH = os.path.join(BASE_DIR, 'db', 'studyrecord')
    for id in os.listdir(DB_PATH):
        file_path = r'%s/%s' % (DB_PATH, id)
        sd = pickle.load(open(file_path, 'rb'))
        if  studyrename == sd.studyrename:
            print('课堂名称：%s  学生名称：%s  签到情况：%s  签到日期：%s 本次成绩：%s' % (sd.classrecordname,sd.studyrename,sd.studyrecordstate,sd.studyrecorddata,sd.studyrecordgrade))


@make_route('20')
def quit():
    sys.exit()


def run():
    msg='''
    1 创建学校
    2 查看学校信息
    3 创建课程
    4 查看课程信息
    5 创建老师
    6 查看老师信息
    7 创建班级
    8 查看班级信息
    9 创建学生
    10 查看学生信息
    11 创建上课记录
    12 查看上课记录
    13 创建学习记录
    14 查看学习记录
    15 退出
    '''
    print(msg)
    while True:
        choice=input('输入你选择>>: ').strip()
        if choice == '15':break
        if choice not in func_dic:
            continue
        func_dic[choice]()



