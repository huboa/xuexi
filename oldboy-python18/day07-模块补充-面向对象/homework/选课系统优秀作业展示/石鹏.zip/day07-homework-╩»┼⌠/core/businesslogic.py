#!/usr/bin/env python3
#_*_coding:utf-8_*_

import uuid
import pickle
import os
from conf import settings

class Base:
    '''
    基础类，主要是利用pickle，保存数据到文件和从文件中读取数据
    '''
    def save(self):
        file_path = r'%s/%s' %(self.DB_PATH, self.guid_id)
        pickle.dump(self, open(file_path, 'wb'))

    @classmethod
    def getinfo_byid(cls, guid_id):
        file_path = r'%s/%s' %(cls.DB_PATH, guid_id)
        return pickle.load(open(file_path, 'rb'))

class School(Base):
    DB_PATH = settings.SCHOOL_PATH
    def __init__(self, name, address, city):
        self.name = name
        self.address = address
        self.city = city
        self.classes = []
        self.teacher = []
        self.guid_id = self.create_id()

    @staticmethod
    def create_id():
        return uuid.uuid1()

    def get_info(self):
        print('''\033[36;1m名称：%s\t\t地址：%s\t\t所在城市：%s\033[0m'''
              % (self.name, self.address, self.city))

    @classmethod
    def get_all_school(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        icount = 0

        for obj in list_obj:
            icount += 1
            print('''\033[35;1m序号：%s\t\t名称：%s\t\t地址：%s\t\t所在城市：%s\033[0m'''
                  %(icount, obj.name, obj.address, obj.city))
        res = {}
        icount = 0
        for school_id in id_list:
            icount += 1
            res[str(icount)] = school_id
        return res

    @classmethod
    def school_del(cls, school_id):
        obj = cls.getinfo_byid(school_id)
        file_path = r'%s/%s' % (cls.DB_PATH, school_id)
        os.remove(file_path)
        print("\033[31;1m学校删除成功[名称：%s]!\033[0m" % obj.name)

class Teacher(Base):
    DB_PATH = settings.TEACHER_PATH

    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex
        self.guid_id = self.create_id()

    @staticmethod
    def create_id():
        return uuid.uuid1()

    def get_info(self):
        print('''\033[36;1m姓名：%s\t年龄：%s\t性别：%s\033[0m'''
              % (self.name, self.age, self.sex))

    @classmethod
    def get_all_teacher(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        icount = 0

        for obj in list_obj:
            icount += 1
            # print('''\033[35;1m序号：%s\t\t姓名：%s\t\t年龄：%s\t\t性别：%s\033[0m'''
            #       % (icount, obj.name, obj.age, obj.sex))
            print('''\033[35;1m序号：%s\t\t姓名：%s\t\t年龄：%s\t\t性别：%s\033[0m'''
                  % (icount, obj.name, obj.age, obj.sex))
        res = {}
        icount = 0
        for teacher_id in id_list:
            icount += 1
            res[str(icount)] = teacher_id
        return res

    @classmethod
    def teacher_del(cls, teacher_id):
        obj = cls.getinfo_byid(teacher_id)
        file_path = r'%s/%s' % (cls.DB_PATH, teacher_id)
        os.remove(file_path)
        print("\033[31;1m删除教师成功[姓名：%s]!\033[0m" % obj.name)

class Classes(Base):
    DB_PATH = settings.CLASSES_PATH

    def __init__(self, name, semester , start_date):
        self.name = name                    # 名称
        self.semester = semester            # 学期
        self.start_date = start_date        # 开课时间
        self.guid_id = self.create_id()     # 班级唯一编号
        self.student = []
        self.teacher = []                   # 讲师
        self.course = []                    # 课程

    @staticmethod
    def create_id():
        return uuid.uuid1()

    def get_info(self):
        print('''\033[36;1m名称：%s\t\t学期：%s\t\t开课日期：%s\033[0m'''
              % (self.name, self.semester, self.start_date))

    @classmethod
    def get_all_classes(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        icount = 0

        for obj in list_obj:
            icount += 1
            print('''\033[35;1m序号：%s\t\t名称：%s\t\t学期：%s\t\t开课日期：%s\033[0m'''
                  % (icount, obj.name, obj.semester, obj.start_date))
        res = {}
        icount = 0
        for classes_id in id_list:
            icount += 1
            res[str(icount)] = classes_id
        return res

    @classmethod
    def get_obj_classes(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]

        return list_obj

    @classmethod
    def classes_del(cls, classes_id):
        obj = cls.getinfo_byid(classes_id)
        file_path = r'%s/%s' % (cls.DB_PATH, classes_id)
        os.remove(file_path)
        print("\033[31;1m删除班级成功[名称：%s]!\033[0m" % obj.name)

    @classmethod
    def student_del(cls,class_list,student_id):
        for obj in class_list:
            # print(obj.student, student_id)
            index = -1
            for std in obj.student:
                index += 1
                # print(std.name)
                if std.guid_id == student_id:
                   break
            if index == -1:
                continue
            else:
                obj.student.pop(index)
                obj.save()
                # print(obj.student, student_id)

class Course(Base):
    DB_PATH = settings.COURSE_PATH

    def __init__(self, name, price , outline):
        self.name = name              # 名称
        self.price = price            # 学期
        self.outline = outline        # 概述
        self.teacher = []
        self.classes = []
        self.guid_id = self.create_id()  # 课程唯一编号

    @staticmethod
    def create_id():
        return uuid.uuid1()

    def get_info(self):
        print('''\033[36;1m名称：%s\t\t价格：%s\t\t概述：%s\033[0m'''
              % (self.name, self.price, self.outline))

    @classmethod
    def get_all_course(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        icount = 0

        for obj in list_obj:
            icount += 1
            print('''\033[35;1m序号：%s\t\t名称：%s\t\t价格：%s\t\t概述：%s\033[0m'''
                  % (icount, obj.name, obj.price, obj.outline))
        res = {}
        icount = 0
        for course_id in id_list:
            icount += 1
            res[str(icount)] = course_id
        return res

    @classmethod
    def course_del(cls, course_id):
        obj = cls.getinfo_byid(course_id)
        file_path = r'%s/%s' % (cls.DB_PATH, course_id)
        os.remove(file_path)
        print("\033[31;1m删除课程成功[名称：%s]!\033[0m" % obj.name)

class Student(Base):
    DB_PATH = settings.STUDENT_PATH

    def __init__(self, name, age , sex):
        self.name = name               # 姓名
        self.age = age                 # 年龄
        self.sex = sex                 # 性别
        self.price = 0.0               # 学费
        self.school = []               # 所属学校
        self.classes = []              # 班级
        self.class_record = []         # 上课记录
        self.guid_id = self.create_id()  # 学生唯一编号

    @staticmethod
    def create_id():
        return uuid.uuid1()

    def get_info(self):
        print('''\033[36;1m姓名：%s\t\t年龄：%s\t\t性别：%s\033[0m'''
              % (self.name, self.age, self.sex))

    @classmethod
    def get_all_student(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        icount = 0

        for obj in list_obj:
            icount += 1
            print('''\033[35;1m序号：%s\t\t姓名：%s\t\t年龄：%s\t\t性别：%s\033[0m'''
                  % (icount, obj.name, obj.age, obj.sex))
        res = {}
        icount = 0
        for stu_id in id_list:
            icount += 1
            res[str(icount)] = stu_id
        return res

    @classmethod
    def student_del(cls, stu_id):
        obj = cls.getinfo_byid(stu_id)
        file_path = r'%s/%s' % (cls.DB_PATH, stu_id)
        os.remove(file_path)
        print("\033[31;1m删除学生成功[姓名：%s]!\033[0m" % obj.name)

class ClassRecord(Base):
    '''
    上课记录
    '''
    DB_PATH = settings.CLASSRECORD_PATH

    def __init__(self, classes, classes_session, attend_date):
        self.classes = classes                   # 班级
        self.classes_session = classes_session   # 节次
        self.attend_date = attend_date          # 时间
        self.student = []                       # 上课学生
        self.guid_id = self.create_id()        # 上课记录唯一编号

    @staticmethod
    def create_id():
        return uuid.uuid1()

    @classmethod
    def get_obj_classrecord(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        return list_obj

    @classmethod
    def get_all_classrecord(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        icount = 0

        for obj in list_obj:
            icount += 1
            print('''\033[35;1m序号：%s\t\t班级：%s\t\t节次：%s\t\t时间：%s\033[0m'''
                  % (icount, obj.classes.name, obj.classes_session, obj.attend_date))
        res = {}
        icount = 0
        for course_id in id_list:
            icount += 1
            res[str(icount)] = course_id
        return res


class StudyRecord(Base):
    '''
    学习记录
    '''
    DB_PATH = settings.STUDYRECORD_PATH

    def __init__(self, class_record, checkin_date, checkin_status, score, student):
        self.class_record = class_record      # 上课记录
        self.checkin_date = checkin_date      # 签到日期
        self.checkin_status = checkin_status  # 签到状态
        self.score = score                    # 成绩
        self.student = student                # 学生
        self.guid_id = self.create_id()       # 学习记录唯一编号

    @staticmethod
    def create_id():
        return uuid.uuid1()

    @classmethod
    def get_all_studyrecord(cls):
        id_list = os.listdir(cls.DB_PATH)
        list_obj = [cls.getinfo_byid(id) for id in id_list]
        return list_obj