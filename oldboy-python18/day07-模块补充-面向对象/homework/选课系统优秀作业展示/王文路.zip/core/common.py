# -*- coding:utf-8 -*-
import sys
import os
import pickle
import time
import hashlib
import time
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)
DB_DIR = '%s/db/'%BASE_DIR
def path_handle(filename):
    return '%s%s.pkl' % (DB_DIR,filename)
def read_db(table):
    f = open(path_handle(table),'rb')
    data = pickle.load(f)
    f.close()
    return data
def write_db(table,data):
    f = open(path_handle(table),'wb')
    pickle.dump(data,f)
    f.close()
def isdata(table):
    return bool(os.path.getsize(path_handle(table)))
def printf(msg,type='correct'):
    if type == 'correct':
        print('\033[32;1m%s\033[1m' % msg)
    elif type == 'error':
        print('\033[31;1m%s\033[1m' % msg)
    else:
        print(msg)
def create_id(*args):
    m = hashlib.md5()
    m.update(str(time.time()).encode('utf-8'))
    return m.hexdigest()
def is_exists(filename):
    if  not os.listdir(filename):
        return True
    else:
        return False
def format_time():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
def id2name(id,file_path):
    for filename in os.listdir(file_path):
        if filename == id:
            file_dir = os.path.join(file_path, id)
            return pickle.load(open(file_dir, 'br'))
    return None
# data1 = {'a': [1, 2.0, 3, 4+6j],
#          'b': ('string', u'Unicode string'),
#          'c': None}
# data1['d'] = 555
# write_db('school',data1)
# data2 = read_db('school')
# data2['d'] = 555
# write_db('school',data2)
# print(read_db('school')['北京'].student)
# school = {'北京':{'python':{'p18':{'teacher':'lucy'},'p19':{}},'linux':{}},'上海':{'go':{}}}
# teacher = {'lucy':{'salary':1000,'class':{'p18','p19'}},'gg':{}}
# classes = {'p18':{'time':'5mon','price':20000,'student':{'zs','ls'}},'l02':{}}
# student = {'zs':{'sex':'male','class':'p18','status':'已注册'},'ls':{'sex':'male','class':'p18','status':'已注册'}}
