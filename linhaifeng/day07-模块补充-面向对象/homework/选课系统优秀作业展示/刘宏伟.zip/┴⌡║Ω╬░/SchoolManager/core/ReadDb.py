#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/16 0016 22:25
# @Author  : LiuHongWei
# @Site    : 
# @File    : ReadDb.py
# @Software: PyCharm

import pickle
import os,sys
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)
from conf import setting

class ReadDb:
    @staticmethod
    def readCourseDb():
        # 通过调用pickle的load方法读取课程信息
        with open(setting.COURSE_PATH, 'rb') as course_file:
            try:
                course_info = pickle.load(course_file)
                course_file.close()
            except EOFError:
                course_info = {}
                course_file.close()
        return course_info
    @staticmethod
    def writeCourseDb(info):
        # 通过调用pickle的write方法存储课程信息
        course_file = open(setting.COURSE_PATH, "wb")
        pickle.dump(info, course_file, 2)
        # user_file.write(info)
        course_file.close()

    @staticmethod
    def readSchoolDb():
        # 通过调用pickle的load方法读取学校信息
        with open(setting.SCHOOL_PATH, 'rb') as school_file:
            try:
                school_info = pickle.load(school_file)
                school_file.close()
            except EOFError:
                school_info = {}
                school_file.close()
        return school_info
    @staticmethod
    def writeSchoolDb(info):
        # 通过调用pickle的write方法存储学校信息
        school_file = open(setting.SCHOOL_PATH, "wb")
        pickle.dump(info, school_file, 2)
        # school_file.write(info)
        school_file.close()

    @staticmethod
    def readTeacherDb():
        # 通过调用pickle的load方法读取教师信息
        with open(setting.TEACHER_PATH, 'rb') as teacher_file:
            try:
                teacher_info = pickle.load(teacher_file)
                teacher_file.close()
            except EOFError:
                teacher_info = {}
                teacher_file.close()
        return teacher_info
    @staticmethod
    def writeTeacherDb(info):
        # 通过调用pickle的write方法存储教师信息
        teacher_file = open(setting.TEACHER_PATH, "wb")
        pickle.dump(info, teacher_file, 2)
        # teacher_file.write(info)
        teacher_file.close()

    @staticmethod
    def readGradeDb():
        # 通过调用pickle的load方法读取班级信息
        with open(setting.GRADE_PATH, 'rb') as grade_file:
            try:
                grade_info = pickle.load(grade_file)
                grade_file.close()
            except EOFError:
                grade_info = {}
                grade_file.close()
        return grade_info
    @staticmethod
    def writeGradeDb(info):
        # 通过调用pickle的write方法存储班级信息
        grade_file = open(setting.GRADE_PATH, "wb")
        pickle.dump(info, grade_file, 2)
        # grade_file.write(info)
        grade_file.close()
    @staticmethod
    def readStudentDb():
        # 通过调用pickle的load方法读取学生信息
        with open(setting.STUDENT_PATH, 'rb') as student_file:
            try:
                student_info = pickle.load(student_file)
                student_file.close()
            except EOFError:
                student_info = {}
                student_file.close()
        return student_info
    @staticmethod
    def writeStudentDb(info):
        # 通过调用pickle的write方法存储学生信息
        student_file = open(setting.STUDENT_PATH, "wb")
        pickle.dump(info, student_file, 2)
        # student_file.write(info)
        student_file.close()
