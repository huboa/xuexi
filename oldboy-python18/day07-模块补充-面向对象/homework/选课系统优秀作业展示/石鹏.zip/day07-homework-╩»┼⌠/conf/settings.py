#!/usr/bin/env python3
#_*_coding:utf-8_*_
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CLASSRECORD_PATH=os.path.join(BASE_DIR,'db','ClassRecord')
CLASSES_PATH=os.path.join(BASE_DIR,'db','Classes')
COURSE_PATH=os.path.join(BASE_DIR,'db','Course')
SCHOOL_PATH=os.path.join(BASE_DIR,'db','School')
STUDENT_PATH=os.path.join(BASE_DIR,'db','Student')
STUDYRECORD_PATH=os.path.join(BASE_DIR,'db','StudyRecord')
TEACHER_PATH=os.path.join(BASE_DIR,'db','Teacher')

