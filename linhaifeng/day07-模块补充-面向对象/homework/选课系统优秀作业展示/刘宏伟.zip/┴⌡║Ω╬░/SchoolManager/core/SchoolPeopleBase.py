#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/16 0016 16:43
# @Author  : LiuHongWei
# @Site    : 
# @File    : SchoolPeopleBase.py
# @Software: PyCharm

class SchoolPeople:
    def __init__(self,name,pass_word,age,sex):
        self.name = name
        self.pass_word = pass_word
        self.age = age
        self.sex = sex
