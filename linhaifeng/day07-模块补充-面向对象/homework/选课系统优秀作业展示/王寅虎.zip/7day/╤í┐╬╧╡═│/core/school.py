#_*_coding:utf-8_*_
import os,sys
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)
import time
import pickle
import os
from lib import common
from conf import settings
DB_PATH =os.path.join(BASE_DIR,'db','school')
class Base:  #序列化 写入磁盘
    def save(self):
        file_path=r'%s/%s' %(self.DB_PATH,self.id)
        pickle.dump(self,open(file_path,'wb'))
    @classmethod
    def get_obj_by_id(cls,id):
        file_path=r'%s\%s' %(cls.DB_PATH,id)
        return pickle.load(open(file_path,'rb'))

class school_add(Base):  #创建学校类
    DB_PATH = os.path.join(BASE_DIR, 'db', 'school')
    def __init__(self,schoolname,address,city):
        self.id = common.create_id()
        self.schoolname=schoolname
        self.address=address
        self.city=city
    @classmethod
    def get_obj_by_schoolname(cls, schoolname):   #判断学校重名
        records = (cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            shcoolname_obj = cls.get_obj_by_id(record.id)
            if schoolname == shcoolname_obj.schoolname:
                return record

class course_add(Base): #创建班级
    DB_PATH = os.path.join(BASE_DIR, 'db', 'course')
    def __init__(self, coursename, price, outline,schoolname):
        self.id = common.create_id()
        self.coursename = coursename
        self.price = price
        self.outline = outline
        self.schoolname = schoolname
    @classmethod
    def get_obj_by_coursename(cls, coursename): #判断班级重名
        records = (cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            coursename_obj = cls.get_obj_by_id(record.id)
            if coursename == coursename_obj.coursename:
                return record

class teacher_add(Base):  # 创建老师
    DB_PATH = os.path.join(BASE_DIR, 'db', 'teacher')
    def __init__(self, teachername,age,sex, schoolname):
        self.id = common.create_id()
        self.teachername = teachername
        self.age = age
        self.sex = sex
        self.schoolname = schoolname
    @classmethod
    def get_obj_by_teachername(cls, teacherename):  # 判断老师重名
        records = (cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            teachername_obj = cls.get_obj_by_id(record.id)
            if teacherename == teachername_obj.teachername:
                return record

class class_add(Base):  # 创建班级
    DB_PATH = os.path.join(BASE_DIR, 'db', 'class')
    def __init__(self, classname, Semester,coursename, schoolname,teachername):
        self.id = common.create_id()
        self.classname = classname
        self.Semester = Semester
        self.coursename = coursename
        self.schoolname = schoolname
        self.teachername = teachername
    @classmethod
    def get_obj_by_classname(cls, classname):  # 判断班级重名
        records = (cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            classname_obj = cls.get_obj_by_id(record.id)
            if classname == classname_obj.classname:
                return record

class student_add(Base):  # 创建学生
    DB_PATH = os.path.join(BASE_DIR, 'db', 'student')
    def __init__(self, studentname,age,sex, classname):
        self.id = common.create_id()
        self.studentname = studentname
        self.age = age
        self.sex = sex
        self.classname = classname
    @classmethod
    def get_obj_by_studentname(cls, studentname):  # 判断学生重名
        records = (cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            studentname_obj = cls.get_obj_by_id(record.id)
            if studentname == studentname_obj.studentname:
                return record

class classrecord_add(Base):  # 创建课堂信息
    DB_PATH = os.path.join(BASE_DIR, 'db', 'classrecord')
    def __init__(self, classrecordname, classrecordnum, classname, classrecorddata):
        self.id = common.create_id()
        self.classrecordname = classrecordname
        self.classrecordnum = classrecordnum
        self.classname = classname
        self.classrecorddata = classrecorddata

    @classmethod
    def get_obj_by_classrecordname(cls, classrecordname):  # 判断课堂信息是否重复
        records = (cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            classrecordname_obj = cls.get_obj_by_id(record.id)
            if classrecordname == classrecordname_obj.classrecordname:
                return record

class studyrecord_add(Base):  # 创建学校记录
    DB_PATH = os.path.join(BASE_DIR, 'db', 'studyrecord')
    def __init__(self, classrecordname,studyrename, studyrecordstate, studyrecorddata,studyrecordgrade):
        self.id = common.create_id()
        self.classrecordname = classrecordname
        self.studyrename = studyrename
        self.studyrecordstate = studyrecordstate
        self.studyrecorddata = studyrecorddata
        self.studyrecordgrade = studyrecordgrade
    @classmethod
    def get_obj_by_studyrecordname(cls,classrecordname,studyrename):  # 判断学生 学习信息是否重复
        records = (cls.get_obj_by_id(id) for id in os.listdir(cls.DB_PATH))
        for record in records:
            studyrecord_obj = cls.get_obj_by_id(record.id)
            if  classrecordname == studyrecord_obj.classrecordname :
                 if studyrename == studyrecord_obj.studyrename:
                     return record

# beijing_school = school('北京沙河老男孩学校','北京市昌平区沙河路','北京市')
# shanghai_school = school('上海陆家嘴老男孩学校','上海市陆家嘴','上海市')
# print(beijing_school.__dict__)
# # beijing_school.save()
# print(school_add.get_obj_by_id('57a6650ffdf33ed10a47ef27d3832070').schoolname)
# #
# for id in os.listdir(DB_PATH):
#      print(id)
# #





