# -*- coding:utf-8 -*-
from core import common,menu
from config import config
from modules import Class
from modules.Handle import Handle

def handle_func():
    return {
        'a':Handle.pay_tuition,
        'b':Handle.personal_info,
        'c':Handle.to_class,
    }
def run():
    while True:
        menu.student_logic_menu()
        service = input('请选择服务编号：').strip()
        if service == '1':
            Handle.create_student()
        elif service == '2':
            while True:
                common.printf(' 学生登录 '.center(40, '/'), 'correct')
                username = input('用户名[q:exit]：').strip()
                if username == 'q': break
                if not username: continue
                password = input('密码：').strip()
                user_info = Class.Students.login(username, password)
                if user_info['flag']:
                    common.printf('登录成功')
                    file_path = user_info['data']
                    while True:
                        menu.student_menu(username)
                        choice = input('请选择服务编号：').strip()
                        if not choice:continue
                        if choice == 'd':break
                        if choice in handle_func():
                            handle_func()[choice](file_path,username)
                        else:
                            common.printf('服务不存在','error')
                else:
                    print('用户名或密码错误请重输入')
        elif service == '3':
            break
        else:
            common.printf('服务不存在','error')

