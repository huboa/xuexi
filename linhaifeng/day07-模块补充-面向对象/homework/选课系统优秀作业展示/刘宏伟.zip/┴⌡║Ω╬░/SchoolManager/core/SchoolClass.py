#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/16 0016 17:15
# @Author  : LiuHongWei
# @Site    : 
# @File    : SchoolClass.py
# @Software: PyCharm
from .CourseClass import Course
from .ReadDb import ReadDb
from .TeacherClass import Teacher
from .GradesClass import Greades
from .CourseClass import Course
from .StudentClass import StudentClass
class School(ReadDb):
    '''学校类'''
    def __init__(self,name):
        self.school_name = name
        self.school_course_list = {}
        self.school_teacher_list = {}
        self.school_greades_list = {}
        self.school_student_list = {}
        # 读取学校数据
        school_list=self.readSchoolDb()
        school_list[self.school_name] = self
        # 存储学校数据
        self.writeSchoolDb(school_list)

    def createCourse(self):
        '''创建课程方法'''
        course_name = input("请输入课程名称：").strip()
        course_cycle = input("请输入课程周期：").strip()
        course_price = input("请输入课程价格：").strip()
        # 创建课程对象
        course_obj = Course(course_name,course_cycle,course_price,self.school_name)
        # 读取课程数据
        course_list=self.readCourseDb()
        course_list[course_name] = course_obj
        # 存储课程信息
        self.writeCourseDb(course_list)

        self.school_course_list[course_name] = course_name
        # 读取学校数据
        school_list=self.readSchoolDb()
        # 存储学校数据
        school_list[self.school_name] = self
        self.writeSchoolDb(school_list)
        print('创建课程成功')
    def createTeacher(self):
        '''创建教师方法'''
        teacher_name = input("请输入老师姓名：").strip()
        teacher_password = input("请输入教师登录密码：").strip()
        teacher_age = input("请输入教师年龄：").strip()
        teacher_sex = input("请输入教师性别：").strip()
        school_name = self.school_name
        teacher = Teacher(teacher_name,teacher_password,teacher_age,teacher_sex,school_name)

        # 读取教师数据
        teacher_info=self.readTeacherDb()
        teacher_info[teacher_name] = teacher
        # 存储教师数据
        self.writeTeacherDb(teacher_info)

        self.school_teacher_list[teacher_name] = teacher_name
        # 读取学校数据
        school_list=self.readSchoolDb()
        # 存储学校数据
        school_list[self.school_name] = self
        self.writeSchoolDb(school_list)
        print('创建老师成功')

    def createGrades(self):
        '''创建班级方法'''
        # 读取教师数据
        teacher_info = self.readTeacherDb()
        greade_name = input("请输入班级名称：").strip()
        # 选择教师
        while True:
            print("请选择本校老师：")
            for name in self.school_teacher_list:
                print(name)
            grade_teacher = input("请输入你要选择的老师姓名：").strip()
            if grade_teacher not in self.school_teacher_list:
                print("您输入的有误请重新输入：")
                continue
            else:
                break
        #选择课程
        while True:
            print("请选择本校课程：")
            for course in self.school_course_list:
                print(course)
            grade_course = input("请输入你要选择的课程名称：").strip()
            if grade_course not in self.school_course_list:
                print("您输入的有误请重新输入：")
                continue
            else:
                break
        grade = Greades(greade_name,grade_course,grade_teacher)
        # 写入学校数据库
        self.school_greades_list[greade_name] = greade_name
        # 读取学校数据
        school_list=self.readSchoolDb()
        # 存储学校数据
        school_list[self.school_name] = self
        self.writeSchoolDb(school_list)

        # 写入教师数据库
        teacher_info[grade_teacher].greade_list[greade_name] = greade_name
        self.writeTeacherDb(teacher_info)

        # 写入班级数据库
        grade_info = self.readGradeDb()
        grade_info[greade_name] = grade
        self.writeGradeDb(grade_info)
        print('创建班级成功')
    def createStudent(self):
        '''创建学生'''
        name = input('请输入您的姓名：').strip()
        pass_word = input('请输入您的密码：').strip()
        age = input('请输入您的年龄：').strip()
        sex = input('请输入您的性别：').strip()
        grade_list = self.readGradeDb()
        while True:
            print('班级信息如下：')
            for i in grade_list:
                print(i)
            grade_name = input('请输入要学的班级名称：')
            if grade_name in grade_list:
                break
            else:
                print('您输入的班级名称有问题，请重新输入:')
                continue

        grade_obj = grade_list[grade_name]
        grade_obj.student_list[name] = name
        grade_list[grade_name] = grade_obj
        # 写入班级学生列表
        self.writeGradeDb(grade_list)

        course_all = self.readCourseDb()
        course_price = course_all[grade_obj.course_name].price
        student_obj = StudentClass(name,pass_word,age,sex,grade_name,grade_obj.course_name,self.school_name,course_price)
        student_all = self.readStudentDb()
        student_all[name] = student_obj
        self.writeStudentDb(student_all)
        print('创建学生成功')



























