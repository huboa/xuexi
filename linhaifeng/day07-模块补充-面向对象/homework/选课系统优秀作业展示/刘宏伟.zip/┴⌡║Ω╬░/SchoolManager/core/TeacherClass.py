#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/16 0016 16:41
# @Author  : LiuHongWei
# @Site    : 
# @File    : TeacherClass.py
# @Software: PyCharm
from .SchoolPeopleBase import SchoolPeople
from .ReadDb import ReadDb
from .StudentClass import StudentClass
from .GradesClass import Greades
import time
class Teacher(SchoolPeople,ReadDb):
    def __init__(self,name,pass_word,age,sex,school_name):
        super().__init__(name,pass_word,age,sex)
        self.greade_list = {}
        self.school_name = school_name
        self.class_record = []

        # 读取班级数据
        teacher_list = self.readTeacherDb()
        teacher_list[self.name] = self
        # 存储班级数据
        self.writeTeacherDb(teacher_list)
    def changeSore(self):
        '''评分'''
        # 读取班级信息
        grade_list = self.readGradeDb()
        # 展示自己所教班级
        while True:
            print("您所教的班级如下：")
            for i in self.greade_list:
                print(i)
            greade_name = input('请输入您要选择的班级:')
            if greade_name in self.greade_list:
                break
            else:
                print('您输入班级有问题，请重新输入：')
                continue

        # 展示所管理班级的学生
        student_list = grade_list[greade_name].student_list

        while True:
            print('您班里的学生有如下：')
            for name in student_list:
                print(name)
            student_name = input('请输入您选择学生:')
            if student_name in student_list:
                break
            else:
                print('您输入学生有问题，请重新输入：')
                continue
        # 读取学生信息
        studnet_all = self.readStudentDb()
        student_task_list = studnet_all[student_name].submit_task
        while True:
            print('该学生作业如下：')
            for task in student_task_list:
                print(task)
            task_name = input('请输入您选择打分的作业:')
            if task_name in student_task_list:
                while True:
                    task_score = input('请输入您的分数:')
                    if task_score.isdigit():
                        student_task_list[task_name] = task_score
                        studnet_all[student_name].submit_task = student_task_list
                        self.writeStudentDb(studnet_all)
                        return True
                    else:
                        print('您输入分数有问题，请重新输入：')
                        continue
            else:
                print('您输入作业有问题，请重新输入：')
                continue
    def showGradeInfo(self):
        '''展示所管理的班级'''
        # 展示自己所教班级
        print("您所教的班级如下：")
        for i in self.greade_list:
            print(i)
        print('*'*18)
    def createClassRecord(self):
        '''展示创建上课记录'''
        # 展示自己所教班级
        while True:
            print("您所教的班级如下：")
            for i in self.greade_list:
                print(i)
            greade_name = input('请输入您要上课的班级:')
            if greade_name in self.greade_list:
                break
            else:
                print('您输入班级有问题，请重新输入：')
                continue
        string = greade_name + time.strftime("%Y-%m-%d %X") + '上课'
        self.class_record.append(string)
        print('记录创建成功')
        # 读取班级数据
        teacher_list = self.readTeacherDb()
        teacher_list[self.name] = self
        # 存储班级数据
        self.writeTeacherDb(teacher_list)

    @staticmethod
    def login():
        '''登录'''
        teacher_all = ReadDb.readTeacherDb()
        name = input('请输入您的姓名：')
        if name in teacher_all:
            teacher_info = teacher_all[name]
            pass_word = input('请输入您的密码：')
            if pass_word == teacher_info.pass_word:
                return teacher_info
            else:
                print('您输入的密码有误,请重新输入')
                return False
        else:
            print("您输入的姓名有误请重新输入")
            return False
    def showInfo(self):
        '''展示老师信息'''
        print('您的详细信息如下：')
        print('姓名：',self.name)
        print('年龄：',self.sex)
        print('所在学校：',self.school_name)
        print('上课记录如下：')
        for class_record in self.class_record:
            print(class_record)
        print('*'*16)