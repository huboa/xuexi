#!/usr/bin/env python3
#_*_coding:utf-8_*_

import logging
from core import businesslogic as logic

logger = logging.getLogger("operation")

def back():
    '''返回系统的主界面'''
    logger.info("返回主界面")
    enter_sys()

def back_manage():
    '''返回上级管理'''
    logger.info("返回上级管理")
    manage_view()

def stu_register():
    '''
    学生注册
    :return:
    '''
    print("\033[43;1m====== 学员注册 ======\033[0m")
    tag = True
    while tag:
        name = input("姓名>>").strip()
        age = input("年龄>>").strip()
        sex = input("性别>>").strip()
        obj = logic.Student(name, age, sex)
        obj.save()
        obj.get_info()
        iscontinue = input("是否继续注册[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def stu_paytuition():
    '''
    学生交学费
    :return:
    '''
    print("\033[43;1m====== 学员交学费 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Student.get_all_student()
        if list_id:
            stu_id = input("交学费的学生序号>>").strip()
            if stu_id in list_id:
                count = input("学费>>").strip()
                if count.isdigit():
                    obj = logic.Student.getinfo_byid(list_id[stu_id])
                    obj.price += float(count)
                    obj.save()
                    print("\033[31;1m%s\033[0m交的学费金额： \033[41;1m%s\033[0m" % (obj.name, count))
                else:
                    print("\033[31;1m%s\033[0m交的学费 \033[41;1m%s\033[0m，不合法，请继续" %(obj.name, count))
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要交学费的学生!\033[0m")
        iscontinue = input("是否继续交学费[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def stu_selectclasses():
    '''
    学生选择班级
    :return:
    '''
    print("\033[43;1m====== 学员选择班级 ======\033[0m")
    tag = True
    while tag:
        print("\033[46;1m====== 学员列表 ======\033[0m")
        list_id = logic.Student.get_all_student()
        if list_id:
            stu_id = input("学生序号>>").strip()
            if stu_id in list_id:
                print("\033[46;1m====== 班级列表 ======\033[0m")
                list_classesid = logic.Classes.get_all_classes()
                classes_id = input("班级序号>>").strip()
                if classes_id in list_classesid:
                    stu_obj = logic.Student.getinfo_byid(list_id[stu_id])
                    cls_obj = logic.Classes.getinfo_byid(list_classesid[classes_id])
                    stu_obj.classes.append(cls_obj)
                    cls_obj.student.append(stu_obj)
                    stu_obj.save()
                    cls_obj.save()
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要选择班级的学生!\033[0m")
        iscontinue = input("是否继续选择班级[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def student_view():
    '''
    选课管理系统，学生管理菜单
    :return:
    '''
    menu = '''
    \033[42;1m====== 欢迎进入学生视图 ======\033[0m
    \033[32;1m1.  注册
    2.  交学费
    3.  选择班级
    4.  返回 \033[0m'''
    menu_dic = {
        '1': stu_register,
        '2': stu_paytuition,
        '3': stu_selectclasses,
        '4': back,
    }
    logger.info("学生视图")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>:").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def show_classes():
    '''
    通过讲师，查看班级
    :return:
    '''
    print("\033[43;1m====== 通过讲师，查看授课班级 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Teacher.get_all_teacher()

        if list_id:
            teacher_id = input("选择讲师的序号>>").strip()
            if teacher_id in list_id:
                teacher_obj = logic.Teacher.getinfo_byid(list_id[teacher_id])
                list_classes = logic.Classes.get_obj_classes()

                icount = 0
                for classes_obj in list_classes:
                    teacher_list = classes_obj.teacher
                    for obj in teacher_list:
                        if obj.guid_id == teacher_obj.guid_id:
                            icount += 1
                            print('''\033[35;1m序号：%s\t\t名称：%s\t\t学期：%s\t\t开课日期：%s\033[0m'''
                                  % (icount, classes_obj.name, classes_obj.semester, classes_obj.start_date))
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要授课的班级!\033[0m")
        iscontinue = input("是否继续查看[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def show_student():
    '''
    讲师通过班级，查看学生
    :return:
    '''
    print("\033[43;1m====== 通过班级查看学生 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Classes.get_all_classes()
        classes_id = input("选择班级序号>>").strip()
        if classes_id in list_id:
            cls_obj = logic.Classes.getinfo_byid(list_id[classes_id])
            student_list = cls_obj.student

            if student_list:
                icount = 0
                for obj in student_list:
                    icount += 1
                    print('''\033[35;1m序号：%s\t\t姓名：%s\t\t年龄：%s\t\t性别：%s\033[0m'''
                          % (icount, obj.name, obj.age, obj.sex))
            else:
                print("\033[31;1m该班级下没有学员!\033[0m")
        else:
            print("\033[31;1m没有要选择的班级!\033[0m")
        iscontinue = input("是否继续查看[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def roll_call():
    '''
    讲师上课点名
    :return:
    '''
    print("\033[43;1m====== 开始点名 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Classes.get_all_classes()
        classes_id = input("选择班级序号>>").strip()
        if classes_id in list_id:
            cls_obj = logic.Classes.getinfo_byid(list_id[classes_id])
            student_list = cls_obj.student
            class_time = input("输入上课时间>>").strip()
            class_session = input("输入上课节次>>").strip()
            obj = logic.ClassRecord(cls_obj, class_session, class_time)
            for student in student_list:
                print("姓名：\033[31;1m[%s]\033[0m" %student.name)
                isflag = input("是否上课[上课:y]>>").strip()
                if isflag == "y":
                    obj.student.append(student)
                    student.class_record.append(obj)
                    student.save()
            else:
                obj.save()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        iscontinue = input("是否继续点名[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def show_rollcall():
    '''
    讲师查看点名
    :return:
    '''
    print("\033[43;1m====== 查看上课情况 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Classes.get_all_classes()
        classes_id = input("选择班级序号>>").strip()
        if classes_id in list_id:
            cls_obj = logic.Classes.getinfo_byid(list_id[classes_id])
            record_list = logic.ClassRecord.get_all_classrecord()
            for obj in record_list:
                if cls_obj.guid_id == obj.classes.guid_id:
                    student_list = obj.student
                    print("\033[43;1m====== 显示已签到的学员列表 ======\033[0m")
                    print('''\033[35;1m班级：%s\t节次：%s\t时间：%s\033[0m'''
                          % (obj.classes.name, obj.classes_session, obj.attend_date))
                    for stu_obj in student_list:
                        print('''\033[32;1m姓名：%s\t\t年龄：%s\t\t性别：%s\033[0m'''
                              % (stu_obj.name, stu_obj.age, stu_obj.sex))
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        iscontinue = input("是否继续查看[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def manage_score():
    '''
    讲师管理成绩
    :return:
    '''
    print("\033[43;1m====== 管理成绩 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.ClassRecord.get_all_classrecord()
        record_id = input("上课记录序号>>").strip()
        if record_id in list_id:
            record_obj = logic.ClassRecord.getinfo_byid(list_id[record_id])
            print('''\033[33;1m班级：%s\t节次：%s\t时间：%s\033[0m'''
                  % (record_obj.classes.name, record_obj.classes_session, record_obj.attend_date))
            checkin_time = input("输入签到日期>>").strip()

            student_list = record_obj.classes.student
            for student in student_list:
                print("姓名：\033[31;1m[%s]\033[0m" % student.name)
                checkin_status = "未签到"
                isflag = input("是否签到[签到:y]>>").strip()
                if isflag == "y":
                    checkin_status = "签到"
                score = input("输入成绩>>").strip()
                checkin_score = "0"
                if score.isdigit():
                    checkin_score = score
                study_obj = logic.StudyRecord(record_obj, checkin_time, checkin_status, checkin_score, student)
                study_obj.save()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        iscontinue = input("是否继续管理成绩[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def show_score():
    '''
    讲师查看成绩
    :return:
    '''
    print("\033[43;1m====== 查看成绩 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.ClassRecord.get_all_classrecord()
        record_id = input("上课记录序号>>").strip()
        if record_id in list_id:
            record_obj = logic.ClassRecord.getinfo_byid(list_id[record_id])
            print('''\033[42;1m班级：%s\t节次：%s\t时间：%s\033[0m'''
                  % (record_obj.classes.name, record_obj.classes_session, record_obj.attend_date))

            studyrecord_list = logic.StudyRecord.get_all_studyrecord()

            for study_obj in studyrecord_list:
                if study_obj.class_record.guid_id == record_obj.guid_id:
                    print('''\033[31;1m姓名：%s\t\t签到日期：%s\t\t签到状态：%s\t\t成绩：%s\033[0m'''
                          % (study_obj.student.name, study_obj.checkin_date, study_obj.checkin_status, study_obj.score))
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        iscontinue = input("是否继续查看成绩[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def teacher_view():
    '''
    选课管理系统，讲师管理菜单
    :return:
    '''
    menu = '''
    \033[42;1m====== 欢迎进入讲师视图 ======\033[0m
    \033[32;1m1.  查看班级
    2.  查看学员
    3.  上课点名
    4.  查看点名
    5.  管理成绩
    6.  查看成绩
    7.  返回 \033[0m'''
    menu_dic = {
        '1': show_classes,
        '2': show_student,
        '3': roll_call,
        '4': show_rollcall,
        '5': manage_score,
        '6': show_score,
        '7': back,
    }
    logger.info("教师视图")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def school_add():
    '''
    学校管理人员，创建学校
    :return:
    '''
    print("\033[43;1m====== 创建学校 ======\033[0m")
    tag = True
    while tag:
        name = input("学校名称>>").strip()
        addr = input("学校地址>>").strip()
        city = input("所在城市>>").strip()
        obj = logic.School(name,addr,city)
        obj.save()
        obj.get_info()
        iscontinue = input("是否继续添加学校[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def school_list():
    '''
    学校管理人员，查看学校列表
    :return:
    '''
    print("\033[43;1m====== 查看学校列表 ======\033[0m")
    logic.School.get_all_school()

def school_del():
    '''
    学校管理人员，删除学校
    :return:
    '''
    print("\033[43;1m====== 删除学校 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.School.get_all_school()
        if list_id:
            school_id = input("要删除学校的序号>>").strip()
            if school_id in list_id:
                logic.School.school_del(list_id[school_id])
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要删除的学校!\033[0m")
        iscontinue = input("是否继续删除学校[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def school_manage():
    '''
    选课管理系统，学校管理
    :return:
    '''
    menu = '''
    \033[43;1m====== 欢迎进入学校管理 ======\033[0m
    \033[32;1m
    1.  创建学校
    2.  查看学校
    3.  删除学校
    4.  返回 \033[0m'''
    menu_dic = {
        '1': school_add,
        '2': school_list,
        '3': school_del,
        '4': back_manage,
    }
    logger.info("学校系统")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def teacher_add():
    '''
    学校管理人员，创建讲师
    :return:
    '''
    tag = True
    while tag:
        print("\033[43;1m====== 添加讲师 ======\033[0m")
        print("\033[31;1m请选择学校\033[0m")
        list_id = logic.School.get_all_school()
        school_id = input("选择学校序号>>").strip()
        if school_id in list_id:
            school_obj = logic.School.getinfo_byid(list_id[school_id])
            name = input("姓名>>").strip()
            age = input("年龄>>").strip()
            sex = input("性别>>").strip()
            obj = logic.Teacher(name, age, sex)
            school_obj.teacher.append(obj)
            obj.save()
            school_obj.save()
            obj.get_info()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        iscontinue = input("是否继续添加讲师[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def teacher_list():
    '''
    学校管理人员，查看讲师列表
    :return:
    '''
    print("\033[43;1m====== 查看讲师列表 ======\033[0m")
    logic.Teacher.get_all_teacher()

def teacher_del():
    '''
    学校管理人员，删除讲师
    :return:
    '''
    print("\033[43;1m====== 删除讲师 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Teacher.get_all_teacher()
        if list_id:
            teacher_id = input("要删除讲师的序号>>").strip()
            if teacher_id in list_id:
                logic.Teacher.teacher_del(list_id[teacher_id])
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要删除的讲师!\033[0m")
        iscontinue = input("是否继续删除讲师[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def teacher_manage():
    '''
    选课管理系统，讲师管理
    :return:
    '''
    menu = '''
        \033[43;1m====== 欢迎进入讲师管理 ======\033[0m
        \033[32;1m
        1.  添加讲师
        2.  查看讲师
        3.  删除讲师
        4.  返回 \033[0m'''
    menu_dic = {
        '1': teacher_add,
        '2': teacher_list,
        '3': teacher_del,
        '4': back_manage,
    }
    logger.info("讲师管理")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def classes_add():
    '''
    学校管理人员，创建班级
    :return:
    '''
    print("\033[43;1m====== 创建班级 ======\033[0m")
    tag = True
    while tag:
        name = input("名称>>").strip()
        semester = input("学期>>").strip()
        start_time = input("开课日期>>").strip()
        obj = logic.Classes(name, semester, start_time)
        obj.save()
        obj.get_info()
        iscontinue = input("是否继续添加班级[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def classes_list():
    '''
    学校管理人员，查看班级列表
    :return:
    '''
    print("\033[43;1m====== 查看班级列表 ======\033[0m")
    logic.Classes.get_all_classes()

def classes_del():
    '''
    学校管理人员，删除班级
    :return:
    '''
    print("\033[43;1m====== 删除班级 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Classes.get_all_classes()
        if list_id:
            classes_id = input("要删除班级的序号>>").strip()
            if classes_id in list_id:
                logic.Classes.classes_del(list_id[classes_id])
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要删除的班级!\033[0m")
        iscontinue = input("是否继续删除班级[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def classes_course():
    '''
    学校管理人员，班级关联课程
    :return:
    '''
    msg = '''\033[43;1m====== 班级关联课程 ======\033[0m'''
    print(msg)
    tag = True
    while tag:
        list_id = logic.Classes.get_all_classes()
        if list_id:
            classes_id = input("选择班级序号>>").strip()
            if classes_id in list_id:
                list_courseid = logic.Course.get_all_course()
                course_id = input("选择课程序号>>").strip()
                if course_id in list_courseid:
                    cls_obj = logic.Classes.getinfo_byid(list_id[classes_id])
                    course_obj = logic.Course.getinfo_byid(list_courseid[course_id])
                    cls_obj.teacher.append(course_obj)
                    course_obj.classes.append(cls_obj)
                    cls_obj.save()
                    course_obj.save()
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要选择班级的学生!\033[0m")
        iscontinue = input("是否继续选择班级[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def classes_teacher():
    '''
    学校管理人员，班级关联讲师
    :return:
    '''
    msg = '''\033[43;1m====== 班级关联讲师 ======\033[0m'''
    print(msg)
    tag = True
    while tag:
        list_id = logic.Classes.get_all_classes()
        if list_id:
            classes_id = input("选择班级序号>>").strip()
            if classes_id in list_id:
                list_teacherid = logic.Teacher.get_all_teacher()
                teacher_id = input("选择讲师序号>>").strip()
                if teacher_id in list_teacherid:
                    cls_obj = logic.Classes.getinfo_byid(list_id[classes_id])
                    teacher_obj = logic.Teacher.getinfo_byid(list_teacherid[teacher_id])
                    cls_obj.teacher.append(teacher_obj)
                    cls_obj.save()
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要选择班级的讲师!\033[0m")
        iscontinue = input("是否继续选择班级[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def classes_manage():
    '''
    选课管理系统，班级管理
    :return:
    '''
    menu = '''
        \033[42;1m====== 班级管理 ======\033[0m
        \033[32;1m
        1.  创建班级
        2.  查看班级
        3.  删除班级
        4.  关联课程
        5.  关联讲师
        6.  返回 \033[0m'''
    menu_dic = {
        '1': classes_add,
        '2': classes_list,
        '3': classes_del,
        '4': classes_course,
        '5': classes_teacher,
        '6': back_manage,
    }
    logger.info("课程管理")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def course_add():
    '''
    学校管理人员，创建课程
    :return:
    '''
    print("\033[43;1m====== 创建课程 ======\033[0m")
    tag = True
    while tag:
        name = input("名称>>").strip()
        price = input("价格>>").strip()
        outline = input("概述>>").strip()
        obj = logic.Course(name, price, outline)
        obj.save()
        obj.get_info()
        iscontinue = input("是否继续添加课程[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def course_list():
    '''
    学校管理人员，查看课程列表
    :return:
    '''
    print("\033[43;1m====== 查看课程列表 ======\033[0m")
    logic.Course.get_all_course()

def course_del():
    '''
    学校管理人员，删除课程
    :return:
    '''
    print("\033[43;1m====== 删除课程 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Course.get_all_course()
        if list_id:
            course_id = input("要删除课程的序号>>").strip()
            if course_id in list_id:
                logic.Course.course_del(list_id[course_id])
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要删除的课程!\033[0m")
        iscontinue = input("是否继续删除课程[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def course_manage():
    '''
    选课系统，课程管理菜单
    :return:
    '''
    menu = '''
        \033[42;1m====== 课程管理 ======\033[0m
        \033[32;1m
        1.  创建课程
        2.  查看课程
        3.  删除课程
        4.  返回 \033[0m'''
    menu_dic = {
        '1': course_add,
        '2': course_list,
        '3': course_del,
        '4': back_manage,
    }
    logger.info("课程管理")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def student_add():
    '''
    学校管理人员，添加学员
    :return:
    '''
    print("\033[43;1m====== 添加学员 ======\033[0m")
    tag = True
    while tag:
        print("\033[43;1m====== 学校列表 ======\033[0m")
        list_id = logic.School.get_all_school()
        if list_id:
            school_id = input("选择学校序号>>").strip()
            if school_id in list_id:
                print("\033[43;1m====== 班级列表 ======\033[0m")
                list_classesid = logic.Classes.get_all_classes()
                classes_id = input("选择班级序号>>").strip()
                if classes_id in list_classesid:
                    school_obj = logic.School.getinfo_byid(list_id[school_id])
                    cls_obj = logic.Classes.getinfo_byid(list_classesid[classes_id])

                    name = input("姓名>>").strip()
                    age = input("年龄>>").strip()
                    sex = input("性别>>").strip()
                    student_obj = logic.Student(name, age, sex)

                    cls_obj.student.append(student_obj)
                    student_obj.classes.append(cls_obj)
                    student_obj.school.append(school_obj)
                    student_obj.save()
                    cls_obj.save()
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要选择的学校!\033[0m")
        iscontinue = input("是否继续选择学校[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def student_list():
    '''
    学校管理人员，查看学员
    :return:
    '''
    print("\033[43;1m====== 查看学员列表 ======\033[0m")
    logic.Student.get_all_student()

def student_del():
    '''
    学校管理人员，删除学员
    :return:
    '''
    print("\033[43;1m====== 删除学员 ======\033[0m")
    tag = True
    while tag:
        list_id = logic.Student.get_all_student()
        if list_id:
            student_id = input("要删除学员的序号>>").strip()
            if student_id in list_id:
                class_list = logic.Student.getinfo_byid(list_id[student_id]).classes
                school_list = logic.Student.getinfo_byid(list_id[student_id]).school
                logic.Classes.student_del(class_list,list_id[student_id])
                logic.Student.student_del(list_id[student_id])
            else:
                print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")
        else:
            print("\033[31;1m没有要删除的学员!\033[0m")
        iscontinue = input("是否继续删除学员[继续y，返回b]>>").strip()
        if iscontinue == "b" or iscontinue == "B":
            tag = False

def student_manage():
    '''
    选课系统学员管理菜单
    :return:
    '''
    menu = '''
        \033[42;1m====== 学员管理 ======\033[0m
        \033[32;1m
        1.  添加学员
        2.  查看学员
        3.  删除学员
        4.  返回 \033[0m'''
    menu_dic = {
        '1': student_add,
        '2': student_list,
        '3': student_del,
        '4': back_manage,
    }
    logger.info("学员管理")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def manage_view():
    '''
    选课系统管理菜单
    :return:
    '''
    menu = '''
    \033[42;1m====== 欢迎进入管理系统 ======\033[0m
    \033[32;1m
    1.  学校管理
    2.  讲师管理
    3.  课程管理
    4.  班级管理
    5.  学员管理
    6.  返回 \033[0m'''
    menu_dic = {
        '1': school_manage,
        '2': teacher_manage,
        '3': course_manage,
        '4': classes_manage,
        '5': student_manage,
        '6': back,
    }
    logger.info("管理系统")
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def logout():
    logger.info("退出系统")
    exit()

def enter_sys():
    '''根据菜单，登录不同系统'''
    menu = '''
    \033[42;1m====== 欢迎进入选课系统 ======\033[0m
    \033[32;1m1.  管理视图
    2.  讲师视图
    3.  学员视图
    4.  退出 \033[0m'''
    menu_dic = {
        '1': manage_view,
        '2': teacher_view,
        '3': student_view,
        '4': logout,
    }
    exit_flag = False
    while not exit_flag:
        print(menu)
        user_option = input(">>").strip()
        if user_option in menu_dic:
            menu_dic[user_option]()
        else:
            print("\033[31;1m选择的内容不存在，请重新选择!\033[0m")

def run():
    logger.info("登录系统")
    print("system is running...")
    enter_sys()
