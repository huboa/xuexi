# -*- coding: utf-8 -*-
# @Author  : ShengLeQi

from core import models
from conf import settings
import sys,time,os

dic_admin={}
def admin_route(name):
    def deco(func):
        dic_admin[name]=func
    return deco

@admin_route('1')
def create_school():
    # print('--crate school--')
    print('创建学校：1、北京 2、上海')
    chice = input('选择学校 >').strip()
    while True:
        if int(chice) == 2:
            Shanghai = models.School('上海', '上海浦东')
            Shanghai.save()
            print('学校%s 创建成功.' %Shanghai.name)
            break
        elif int(chice) == 1:
            Beijing = models.School('北京', '北京沙河')
            Beijing.save()
            print('学校%s 创建成功.' % Beijing.name)
            break
        else: continue

@admin_route('2')
def cat_school():
    print('--cat school--')
    recodes=models.School.get_all(settings.SCHOOL_PATH)
    for i in recodes:
        print('学校名：%s 地址：%s' %(i.name,i.address))

@admin_route('3')
def create_classes():
    # print('--crate classes--')
    print('创建班级')
    name=input('输入班级名字：').strip()
    semester=input('输入班级期数：>').strip()
    date=input('开课时间>').strip()
    Class_l=models.Classes(name,semester,date)
    Class_l.save()
    print('班级%s 创建成功.'%Class_l.name)

@admin_route('4')
def cat_classes():
    # print('--cat classes--')
    recodes=models.Classes.get_all(settings.CLASSES_PATH)
    for i in recodes:
        print('课程名称：%s ' %(i.name))

@admin_route('5')
def create_course():
    # print('--create_clourse--')
    msg='''
    1、课程名：Python 价格：9999 周期：5mons
    2、课程名：Linux 价格：15800 周期：6mons
    3、课程名：Go 价格：8000 周期：7mons
    0、退出
    '''
    print(msg)
    while True:
        chice=input('选择课程 >').strip()
        if int(chice) == 1:
            Python = models.Course('Python', 9999, '5mons')
            Python.save()
            print('课程%s 创建成功.'%Python.name)
            break
        elif int(chice) == 2:
            Linux = models.Course('Linux', 15800, '6mons')
            Linux.save()
            print('课程%s 创建成功.' % Linux.name)
            break
        elif int(chice) == 3:
            Go = models.Course('Go', 8000, '7mons', )
            Go.save()
            print('课程%s 创建成功.' % Go.name)
            break
        elif int(chice) == 0:
            break
        else:continue

@admin_route('6')
def cat_course():
    # print('--cat_clourse--')
    recodes=models.Course.get_all(settings.COURSE_PATH)
    for i in recodes:
        print('名字：%s 价格：%s 周期：%s'%(i.name,i.price,i.period))

@admin_route('7')
def create_teacher():
    # print('--create_teacher--')
    name=input('讲师名字 >').strip()
    salary=input('讲师薪资 >').strip()
    teacher = models.Teacher(name, salary)
    teacher.save()

@admin_route('8')
def cat_teacher():
    # print('--cat_teacher--')
    recodes=models.Teacher.get_all(settings.TEACHER_PATH)
    for i in recodes:
        print('名字：%s 薪资：%s '%(i.name,i.salary))

@admin_route('9')
def cat_student():
    print('--cat_student--')
    recodes = models.School.get_all(settings.SCHOOL_PATH)
    for i in recodes:
        for j in i.student:
            print('所在学校:%s 学生:%s 年龄:%s'%(i.name,j.name,j.age))


def show_admin():
    t_msg = '''
    ----------------------选项--------------------------------
                    1 创建学校
                    2 查看学校
                    3 创建班级
                    4 查看班级
                    5 创建课程
                    6 查看课程
                    7 创建讲师
                    8 查看讲师
                    9 查看学生
                    0 退出
    -----------------------------------------------------------
                    '''
    print(t_msg)

def run():
    print('管理员登录..')
    res=models.School.get_all(settings.SCHOOL_PATH)
    if not res:
        print('判断是否有学校，没有先创建。')
        dic_admin['1']()
    while True:
        show_admin()
        chice = input('选择 >').strip()
        if chice.isdigit() and int(chice) > 0 and int(chice) < 10:
            dic_admin[chice]()
        elif chice.isdigit() and int(chice) == 0:
            break
