'''
hashlib加密算法

常用属性

hashlib.algorithms
列出所有加密算法

h.digest_size
产生的散列字节大小。

h.block_size
哈希内部块的大小

常用方法

hash.new([arg])
创建指定加密模式的hash对象

hash.update(arg)
更新哈希对象以字符串参数。如果同一个hash对象重复调用该方法，m.update(a); m.update(b) 等价于 m.update(a+b)

hash.digest()
返回摘要，作为二进制数据字符串值。

hash.hexdigest()
返回摘要，作为十六进制数据字符串值

hash.copy()
复制

'''
__author__ = 'seagull'
import  hashlib
import time
username='his'
userpass='123'
def create_id(*args):
    m=hashlib.md5()
    m.update(str(time.time()).encode('utf-8'))
    return m.hexdigest()

if __name__=='__main__':
    a=create_id(userpass)
    print(a)
    with open('a.txt','w',encoding='utf-8') as f:
        f.write(a)
    with open('a.txt','r',encoding='utf-8') as f_w:
        f_r=f_w.read()
    if username in f_r:
        print('ok')
    else:
        print('no')






