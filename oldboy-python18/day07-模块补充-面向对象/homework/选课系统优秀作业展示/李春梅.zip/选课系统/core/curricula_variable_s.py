#_*_coding:utf-8_*_
'''
student

'''
__author__='seagull'
import os
from conf.profile import *
from lib.option import *
import time
import logging
from  conf.logging_tem import *
logger = logging.getLogger(__name__)





class school:
    def __init__(self,name,address):
        self.name=name
        self.address=address
    def tale(self):
        return  '学校:%s \n学校地址:%s'\
                 %(self.name,self.address)

class course():
    def __init__(self,name,price,cycle,outline):
        self.name=name
        self.price=price
        self.cycle=cycle
        self.outline=outline
    def tale(self):
        return '课程:%s  \n课程价钱:%s  \n课程周期:%s  \n课程大纲:%s'\
                 %(self.name,self.price,self.cycle,self.outline)

class classes():
    def __init__(self,name,term,course,start_data,teacher):
        self.name=name
        self.term=term
        self.course=course
        self.start_data=start_data
        self.teacher=teacher
    def tale(self):
        return '班级:%s \n学期:%s \n本班课程:%s  \n开课时间:%s  \n本班讲师:%s'\
                 %(self.name,self.term,self.course,self.start_data,self.teacher)





def student_in():
    print('欢迎进入选课系统，正在加载资源，请稍后....')
    time.sleep(1)
    for n in os.walk(PATH_SCHOOL):
        for line in n[2]:
            print(line,end='\n')
        school_choose = input('请选择所在学校:')
        if school_choose not in n[2]:
            print('学校不存在')
            option_student()
        path=os.path.join(PATH_SCHOOL,school_choose)
        with open(path,'r+',encoding='utf-8') as f_v:
            f_v=eval(f_v.read())
            res=school(f_v['name'],f_v['address'])
            print(school.tale(res))
    print('课程：')
    for n in os.walk(PATH_COURSE):
        for line in n[2]:
            print('%s'%line, end='\n')
    print('最近开课班级：')
    for n in os.walk(PATH_CLASSES):
        for line in n[2]:
            print('%s' % line, end='\n')
    judge=input('是否查看详细信息？\n'
                '如果是，请选择查看课程还是班级详细信息，如果否，请按任意键退出:')
    if judge=='课程':
        def course_info():
            for n in os.walk(PATH_COURSE):
                for line in n[2]:
                    print(line)
                course_choose=input('请选择查看的课程：')
                if course_choose not in n[2]:
                    print('课程不存在')
                    course_info()
                path = os.path.join(PATH_COURSE, course_choose)
                with open(path, 'r+', encoding='utf-8') as f_v:
                    f_v = eval(f_v.read())
                    res =course(f_v['name'], f_v['price'],f_v['cycle'],f_v['outline'])
                    print(course.tale(res))
        course_info()
        student_in()
    elif judge == '班级':
        def classes_info():
            for n in os.walk(PATH_CLASSES):
                for line in n[2]:
                    print(line)
                course_choose=input('请选择查看的班级：')
                if course_choose not in n[2]:
                    print('班级不存在')
                    classes_info()
                path = os.path.join(PATH_CLASSES, course_choose)
                with open(path, 'r+', encoding='utf-8') as f_v:
                    f_v = eval(f_v.read())
                    res =classes(f_v['name'], f_v['term'],f_v['course'],f_v['start_data'],f_v['teacher'])
                    print(classes.tale(res))
        classes_info()
        student_in()
    else:
        option_student()





        # path=os.path.join(PATH_COURSE,)




def option_student():

    for k,v in option3.items():
        print(k)
    judge=input('请选择：').strip()
    if judge=='查看':
        for v in option3[judge]:
            print(option3[judge].index(v),v)
        judge=int(input('请选择序号[0-1]：').strip())
        if judge==0:
            student_in()
        elif judge==1:
            path=os.path.join(PATH_STUDENT,currunt[0])
            with open(path,'r',encoding='utf-8') as f_r:
                print(f_r.read())
            option_student()
        else:
            print('输入错误！')
            option_student()
    elif judge=='选课':
        for n in os.walk(PATH_COURSE):
            for i in n[2]:
                print(i)
        judge=input('请选择你想要学习的课程：')
        school=input('请输入所在学校：')
        path=os.path.join(PATH_STUDENT,currunt[0])
        with open(path, 'r', encoding='utf-8') as f_r:
            info_people=eval(f_r.read())
            name=info_people['name']
            age=info_people['age']
            for n in os.walk(PATH_CLASSES):
                for i in n[2]:
                    path1=os.path.join(PATH_CLASSES,i)
                    with open(path1,'r',encoding='utf-8') as f_classes:
                        classes_info=eval(f_classes.read())
                        if judge==classes_info['course']:
                            teacher=classes_info['teacher']
                            classes=classes_info['name']
                            start_data=classes_info['start_data']
                            path2=os.path.join(PATH_STUDENT,currunt[0])
                            with open(path2, 'w', encoding='utf-8') as f_w:
                                f_w.write('{"name":"%s",\n"age":%s,\n"teacher":%s,\n"classes":%s,\n"course":%s,'
                                              '\n"start_data":"%s",\n"school":%s,\n"other":[]}'
                                            % (name, age, teacher, classes, judge, start_data,school))
        option_student()
    elif judge=='签到':
        path = os.path.join(PATH_STUDENT,currunt[0])
        with open(path, 'r', encoding='utf-8') as f_r:
            info_people = eval(f_r.read())
            name = info_people['name']
            age = info_people['age']
            teacher = info_people['teacher']
            classes=info_people['classes']
            school=info_people['school']
            time1=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime())
            other=info_people['other'].append('签到成功：%s\n'%time1)
            with open(path, 'w', encoding='utf-8') as f_w:
                    f_w.write('{"name":"%s",\n"age":%s,\n"teacher":%s,\n"classes":%s,\n"course":%s,'
                       '\n"school":%s,\n"other":%s}'
                        % (name, age, teacher, classes, judge, school,other))
        option_student()
    elif judge=='提交作业':
        print('暂未开放，敬请期待！')
    elif judge=='退出':
        exit()
    else:
        option_student()






















