#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/16 0016 22:30
# @Author  : LiuHongWei
# @Site    : 
# @File    : setting.py
# @Software: PyCharm

import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 课程数据存放路径
COURSE_PATH = os.path.join(BASE_DIR,'db','course.txt')
# 学校数据存放路径
SCHOOL_PATH = os.path.join(BASE_DIR,'db','school.txt')
# 教师数据存放路径
TEACHER_PATH = os.path.join(BASE_DIR,'db','teacher.txt')
# 班级数据存放路径
GRADE_PATH = os.path.join(BASE_DIR,'db','grade.txt')
# 学生数据存放路径
STUDENT_PATH = os.path.join(BASE_DIR,'db','student.txt')

# 主菜单字典
main_dic = {'1':'管理员系统','2':'学生系统','3':'老师系统','4':'退出'}
# 学生系统菜单
student_main = {'1':'注册','2':'登录系统','3':'退出'}
# 学生登录系统后菜单
student_dic = {'1':'查询个人详情','2':'交学费','3':'交作业','4':'返回'}
# 管理员系统菜单
master_dic = {'1':'创建学校','2':'创建老师','3':'创建课程','4':'创建班级','5':'退出'}
# 教师系统菜单
teacher_dic = {'1':'查询个人信息','2':'查询所管班级','3':'创建上课记录','4':'评分','5':'返回'}