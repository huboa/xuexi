#作业说明(选课系统)
##目录说明
    ├─ main.py                  //程序入口文件
    ├─ bin                      //程序执行目录
    │  └─ start.py              //程序执行文件
    ├─ config                   //配置文件目录
    │  └─ config.py             //配置文件
    ├─ core                     //核心业务目录
    │  ├─ admin_logic.py        //后台(学校)主逻辑模块
    │  ├─ student_logic.py      //学生主逻辑模块
    │  ├─ teacher_logic.py      //老师主逻辑模块
    │  ├─ common.py             //通用函数库
    │  └─ menu.py               //通用菜单
    ├─ db                       //数据存储目录
    │  ├─ admin                 //管理员数据目录
    │  ├─ classes               //班级数据目录
    │  ├─ course                //课程数据目录
    │  ├─ schools               //学校数据目录
    │  ├─ students_file         //学生数据目录
    │  ├─ teacher_course        //讲师与课程关联数据目录
    │  └─ teacher_file          //讲师数据目录
    ├─ modules                  //类文件目录
    │  ├─ Class.py              //定义初始类
    │  └─ Handle.py             //逻辑处理类
    ├─ system.png               //程序流程图
    └─ readme.md                //程序说明文件
## 运行环境
    Python 3.6.1
## 功能介绍
    * 可直接运行main.py执行程序
    * 程序说明：
        - 本系统共分为学生端、教师端、学校端(后台管理)三大模块
            + 学生端：注册、登录、缴费、上课、个人信息查看
            + 教师端：班级学生列表、学生成绩管理、选择班级上课
            + 学校端：添加学校、查看学校、添加课程、查看课程、添加老师、查看老师、课程关联、查看关联 、添加班级、查看班级、添加学生、查看学生
        - 系统设计成单一入口(main.py),由bin/start.py做分发
        - 各个目录文件的功能描述在目录树中有展现
        - 提供初始数据(可将db目录下的各目录中的文件清空，如：删除db/classes/xxxx)：
            + 学校端 用户名：admin;密码：admin    (db/admin/文件被清空时需按照程序提示初始化管理员账户)
        - Class中定义了Base父类和Admin、School、Classes、Teacher、Course、Students、TeacherCourse、Score八个基础类
        - Handle中定义了Handle类与若干非绑定方法用于辅助Class中的基础类与逻辑的结合
    * 程序缺陷说明：
        - 程序中需要根据编号选择的时候需要按照提示的编号输入，程序暂时没做处理，如若输入非指定编号会报错
##博客地址
    [我的博客](https://www.loyous.com/index.php/archives/23/)(模块补充)
    [我的博客](https://www.loyous.com/index.php/archives/24/)(面向对象)





