# -*- coding:utf-8 -*-
import os,sys,pickle
from prettytable import PrettyTable
from core import common
from config import config
from modules import Class
class Handle:
    @staticmethod
    def create_school():
        common.printf('添加学校模块','correct')
        name = input('请输入学校名[b:返回]：').strip()
        if name == 'b':
            return
        addr = input('请输入学校地址[b:返回]：').strip()
        if addr == 'b':
            return
        schools_list = [(obj.name,obj.addr) for obj in Class.School.open_file_list()]
        if (name, addr) in schools_list:
            common.printf('%s 校区已存在'%name,'error')
            return
        else:
            obj = Class.School(name, addr)
            obj.save()
            common.printf('%s 校区添加成功'%name,'correct')
            return
    @staticmethod
    def create_class():
        common.printf('添加班级模块', 'correct')
        school_list = Class.School.open_file_list()
        line = PrettyTable(['编号', '校区', '学校地址', '添加时间'])
        line.align = "l"
        line.padding_width = 1
        for k,obj in enumerate(school_list):
            line.add_row([k,obj.name, obj.addr, obj.create_time])
        common.printf(line)
        school_choice = input('请选择学校编号[b:返回]：').strip()
        if school_choice == 'b':return
        school_obj = school_list[int(school_choice)]
        class_name = input('请输入要添加的班级名[b:返回]：').strip()
        if class_name == 'b': return
        class_list = [(obj.name, obj.school_id) for obj in Class.Classes.open_file_list()]
        if (class_name,school_obj.id) in class_list:
            common.printf('该班级已存在','error')
            return
        else:
            teacher_course_list=Class.TeacherCourse.open_file_list()
            line = PrettyTable(['课程编号','讲师名:课程名'])
            line.align = 'l'
            line.padding_width = 1
            for k,obj in enumerate(teacher_course_list):
                if school_obj.id==obj.school_id:
                    line.add_row([k,obj.name])
            common.printf(line)
            coures_name=input('请选择编号[b:返回]：').strip()
            if coures_name == 'b': return
            teacher_course_obj=teacher_course_list[int(coures_name)]
            obj=Class.Classes(school_obj.id,class_name,teacher_course_obj.id)
            obj.save()
            common.printf('%s 班级添加成功'%obj.name)
            return

    @staticmethod
    def create_teacher():
        common.printf('添加讲师模块', 'correct')
        school_list = Class.School.open_file_list()
        line = PrettyTable(['编号', '校区', '学校地址', '添加时间'])
        line.align = "l"
        line.padding_width = 1
        for k, obj in enumerate(school_list):
            line.add_row([k, obj.name, obj.addr, obj.create_time])
        common.printf(line)
        school_choice = input('请选择学校编号[b:返回]：').strip()
        if school_choice == 'b': return
        school_obj = school_list[int(school_choice)]
        name = input('请输入讲师名：').strip()
        pwd = input('请输入讲师密码：').strip()
        salary = input('请输入讲师薪资：').strip()
        age = input('请输入年龄：').strip()
        sex = input('请输入性别：').strip()
        name_list = [(obj.name, obj.school_id) for obj in Class.Teacher.open_file_list()]
        if (name,school_obj.id) in name_list:
            common.printf('讲师 %s 已经存在'%name,'error')
            return
        else:
            obj=Class.Teacher(name,pwd,age,sex,salary,school_obj.id)
            obj.save()
            common.printf('添加成功','correct')
            return

    @staticmethod
    def create_course():
        common.printf('添加课程模块', 'correct')
        school_list = Class.School.open_file_list()
        line = PrettyTable(['编号', '校区', '学校地址', '添加时间'])
        line.align = "l"
        line.padding_width = 1
        for k, obj in enumerate(school_list):
            line.add_row([k, obj.name, obj.addr, obj.create_time])
        common.printf(line)
        school_choice = input('请选择学校编号[b:返回]：').strip()
        if school_choice == 'b': return
        school_obj = school_list[int(school_choice)]
        course_name = input('请输入要创建的课程名：').strip()
        price = input('请输入课程价格: ').strip()
        period = input('请输入课程周期: ').strip()
        course_name_list = [(obj.name, obj.school_id) for obj in Class.Course.open_file_list()]
        if (course_name,school_obj.id) in course_name_list:
            print('\033[43;1m课程[%s] 已经存在,不能重复创建\033[0m' %(course_name))
            common.printf('课程 %s 已经存在'%course_name,'error')
            return
        else:
            obj=Class.Course(course_name,period,price,school_obj.id)
            obj.save()
            common.printf('课程[%s] 价格[%s] 周期[%s]创建成功' %(obj.name,obj.price,obj.cycle))
            return

    @staticmethod
    def create_student():
        common.printf('添加学生模块', 'correct')
        school_list = Class.School.open_file_list()
        line = PrettyTable(['编号', '校区', '学校地址', '添加时间'])
        line.align = "l"
        line.padding_width = 1
        for k, obj in enumerate(school_list):
            line.add_row([k, obj.name, obj.addr, obj.create_time])
        common.printf(line)
        school_choice = input('请选择学校编号[b:返回]：').strip()
        if school_choice == 'b': return
        school_obj = school_list[int(school_choice)]
        student_list = [(obj.num, obj.phone) for obj in Class.Students.open_file_list()]
        student_id = input('请输入学员唯一编号：').strip()
        if not student_id.isdigit():return
        if int(student_id) in student_list:
            common.printf('学号%s已经存在' %student_id,'error')
            return
        name = input('请输入要创建学员名字：').strip()
        password = input('请输入学员登陆密码：').strip()
        phone = input('请输入电话号码:').strip()
        age = input('请输入年龄：').strip()
        sex = input('请输入性别：').strip()
        if phone in student_list:
            common.printf('%s电话号码已经存在' % phone,'error')
            return
        else:
            class_list = Class.Classes.open_file_list()
            line_class = PrettyTable(['班级编号','班级名称'])
            line_class.align = "l"
            line_class.padding_width = 1
            for k, obj in enumerate(class_list):
                if school_obj.id == obj.school_id:
                    line_class.add_row([k,obj.name])
            common.printf(line_class)
            class_choice = input('请选择班级编号:').strip()
            class_obj = class_list[int(class_choice)]
            obj = Class.Students(student_id, name, password, age, sex, school_obj.id, class_obj.id, phone)
            obj.save()
            common.printf('%s校区学员 %s 添加成功'%(school_obj.name,obj.name))
            return

    @staticmethod
    def create_relation():
        common.printf('添加关联模块', 'correct')
        school_list = Class.School.open_file_list()
        line = PrettyTable(['编号', '学校', '地址', '添加时间'])
        line.align = "l"
        line.padding_width = 1
        for k, obj in enumerate(school_list):
            line.add_row([k, obj.name, obj.addr, obj.create_time])
        common.printf(line)
        school_choice = input('请选择学校编号[b:返回]：').strip()
        if school_choice == 'b': return
        school_obj = school_list[int(school_choice)]
        course_list = Class.Course.open_file_list()
        line_course = PrettyTable(['编号', '课程名', '添加时间'])
        line_course.align = 'l'
        line_course.padding_width = 1
        for k,obj in enumerate(course_list):
            if obj.school_id == school_obj.id:
                line_course.add_row([k,obj.name,obj.create_time])
        common.printf(line_course)
        course_choice = input('请选择课程编号[b:返回]：').strip()
        if course_choice == 'b': return
        course_obj = course_list[int(course_choice)]
        teacher_list = Class.Teacher.open_file_list()
        line_teacher = PrettyTable(['编号', '讲师名', '添加时间'])
        line_teacher.align = 'l'
        line_teacher.padding_width = 1
        for k, obj in enumerate(teacher_list):
            if obj.school_id == school_obj.id:
                line_teacher.add_row([k,obj.name,obj.create_time])
        common.printf(line_teacher)
        teacher_choice = input('请选择讲师编号[b:返回]：').strip()
        if teacher_choice == 'b': return
        teacher_obj = teacher_list[int(teacher_choice)]
        relation_list = [(obj.course_name,obj.teacher_name,obj.school_id) for obj in Class.TeacherCourse.open_file_list()]
        if (course_obj.name,teacher_obj.name,school_obj.id) in relation_list:
            common.printf('[%s]校区的课程[%s]与讲师[%s]已经建立关系'%(school_obj.name,course_obj.name,teacher_obj.name),'error')
            return
        else:
            obj=Class.TeacherCourse(course_obj.name,teacher_obj.name,school_obj.id)
            obj.save()
            common.printf('[%s]校区的课程[%s]与讲师[%s]关系建立成功' % (school_obj.name, course_obj.name, teacher_obj.name), 'correct')
            return

    @staticmethod
    def select_school():
        common.printf('查看学校模块', 'correct')
        line = PrettyTable(['校区', '学校地址', '添加时间'])
        line.align = "l"
        line.padding_width = 1
        for obj in Class.School.open_file_list():
            line.add_row([obj.name, obj.addr,obj.create_time])
        common.printf(line)

    @staticmethod
    def select_class():
        common.printf('查看班级模块', 'correct')
        line = PrettyTable(['校区', '学校地址', '班级','课程','讲师'])
        line.align = "l"
        line.padding_width = 1
        for obj in Class.Classes.open_file_list():
            line.add_row([common.id2name(obj.school_id,Class.School.file_path).name,
                          common.id2name(obj.school_id, Class.School.file_path).addr,
                          obj.name,
                          common.id2name(obj.teacher_course_id, Class.TeacherCourse.file_path).course_name,
                          common.id2name(obj.teacher_course_id, Class.TeacherCourse.file_path).teacher_name,
                          ])
        common.printf(line)

    @staticmethod
    def select_teacher():
        common.printf('查看讲师模块', 'correct')
        line = PrettyTable(['校区', '学校地址', '讲师名','年龄','性别','薪资','入职时间'])
        line.align = "l"
        line.padding_width = 1
        for obj in Class.Teacher.open_file_list():
            line.add_row([common.id2name(obj.school_id,Class.School.file_path).name,
                          common.id2name(obj.school_id, Class.School.file_path).addr,
                          obj.name,obj.age,obj.sex,obj.salary,obj.create_time
                          ])
        common.printf(line)

    @staticmethod
    def select_course():
        common.printf('查看课程模块', 'correct')
        line = PrettyTable(['校区', '学校地址', '课程名','价格','周期','创建日期'])
        line.align = "l"
        line.padding_width = 1
        for obj in Class.Course.open_file_list():
            line.add_row([common.id2name(obj.school_id,Class.School.file_path).name,
                          common.id2name(obj.school_id, Class.School.file_path).addr,
                          obj.name,obj.price,obj.cycle,obj.create_time
                          ])
        common.printf(line)

    @staticmethod
    def select_student():
        common.printf('查看学生模块', 'correct')
        line = PrettyTable(['校区', '学校地址', '班级', '学生编号', '学生姓名', '年龄', '性别', '手机号码', '报到时间'])
        line.align = "l"
        line.padding_width = 1
        for obj in Class.Students.open_file_list():
            line.add_row([common.id2name(obj.school_id, Class.School.file_path).name,
                          common.id2name(obj.school_id, Class.School.file_path).addr,
                          common.id2name(obj.class_id, Class.Classes.file_path).name,
                          obj.number, obj.name, obj.age, obj.sex, obj.phone, obj.create_time
                          ])
        common.printf(line)

    @staticmethod
    def select_relation():
        common.printf('查看课程关联模块', 'correct')
        line = PrettyTable(['校区', '学校地址', '课程名', '讲师名'])
        line.align = "l"
        line.padding_width = 1
        for obj in Class.TeacherCourse.open_file_list():
            line.add_row([common.id2name(obj.school_id, Class.School.file_path).name,
                          common.id2name(obj.school_id, Class.School.file_path).addr,
                          obj.course_name, obj.teacher_name
                          ])
        common.printf(line)

    @staticmethod
    def pay_tuition(*args):
        file_path = args[0]
        obj = pickle.load(open(file_path, 'rb'))
        money = input('请输入学费金额:').strip()
        if money.isdigit() and int(money) > 0:
            obj.tuition = obj.tuition + int(money)
            obj.save()
            common.printf('本次成功缴纳学费金额为：%s'%money)
        else:
            common.printf('缴纳金额应为正整数','error')

    @staticmethod
    def personal_info(*args):
        file_path = args[0]
        obj = pickle.load(open(file_path, 'rb'))
        Handle.show_info(obj)

    @staticmethod
    def to_class(*args):
        file_path = args[0]
        obj = pickle.load(open(file_path, 'rb'))
        class_name = common.id2name(common.id2name(obj.class_id,Class.Classes.file_path).teacher_course_id,Class.TeacherCourse.file_path).course_name
        for class_obj in Class.Course.open_file_list():
            if class_name == str(class_obj.name):
                if int(obj.tuition) >= int(class_obj.price):
                    common.printf('进入上课模式')
                    question = input('请回答问题：1+1=？').strip()
                    if question == '2':
                        common.printf('您已掌握本节课内容')
                    else:
                        common.printf('继续努力哦')
                    continue
                else:
                    common.printf('请缴纳剩余学费%s'%(int(class_obj.price)-int(obj.tuition)))
                    continue

    @staticmethod
    def show_info(obj):
        common.printf('''
        学号：{number}      
        姓名：{name}        
        年龄：{age}         
        性别：{sex}         
        电话：{phone}
        校区：{school}
        地址：{addr}
        班级：{classes}
        学费：{tui}
        分数：{score}
        '''.format(number = obj.number,name = obj.name,age = obj.age,sex = obj.sex,phone = obj.phone,
                   school = common.id2name(obj.school_id,Class.School.file_path).name,
                   addr = common.id2name(obj.school_id,Class.School.file_path).addr,
                   classes = common.id2name(obj.class_id, Class.Classes.file_path).name,
                   tui = str(obj.tuition),score = obj.score.score_dict
                   ))