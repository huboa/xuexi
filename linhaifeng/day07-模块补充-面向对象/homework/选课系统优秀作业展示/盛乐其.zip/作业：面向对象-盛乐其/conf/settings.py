#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/8/13 18:23
# @Author  : ShengLeQi

import os
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


QUESTION_PATH=os.path.join(BASE_DIR,'db','submit_job')
REGISTER_PATH=os.path.join(BASE_DIR,'db','register')
RECORD_PATH=os.path.join(BASE_DIR,'db','record')
TEACHER_PATH=os.path.join(BASE_DIR,'db','teacher')
STUDENT_PATH=os.path.join(BASE_DIR,'db','student')
COURSE_PATH=os.path.join(BASE_DIR,'db','course')
CLASSES_PATH=os.path.join(BASE_DIR,'db','classes')
SCHOOL_PATH=os.path.join(BASE_DIR,'db','school')

# C 2P_PATH=os.path.join(BASE_DIR,'db','customer_to_prize')