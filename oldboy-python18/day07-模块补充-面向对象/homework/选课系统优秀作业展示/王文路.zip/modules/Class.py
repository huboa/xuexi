# -*- coding:utf-8 -*-
import os,sys,pickle,time
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))#获取相对路径转为绝对路径赋于变量
sys.path.append(BASE_DIR)
from config import config
from core import common
class Base:
    def save(self):
        file_dir=os.path.join(self.file_path,str(self.id))#拼接文件路径
        pickle.dump(self,open(file_dir,'wb'))#序列化到文件
    @classmethod
    def open_file_list(cls):#传入当前类
        list_l=[]#定义一个列表
        for file in os.listdir(cls.file_path):#循环输出对应目录下的文件
            file_dir=os.path.join(cls.file_path,file)##拼接文件路径
            list_l.append(pickle.load(open(file_dir,'rb')))#反序列化,追加到列表
        return list_l#返回列表
    def get_id_file(self):#通过ID找到对应文件
        for filename in os.listdir(self.file_path):
            if filename == self.id:
                file_dir=os.path.join(self.file_path,self.id)#拼接文件路径
                return pickle.load(open(file_dir,'br'))#返回反序列化的文件对象
        return None

class Admin(Base):
    file_path = config.ADMIN_DIR
    def __init__(self,user,pwd):
        self.id=common.create_id()
        self.USER=user
        self.PWD=pwd
    @staticmethod
    def login(username,password):
        try:
            for obj in Admin.open_file_list():
                if obj.USER == username and obj.PWD == password:
                    flag=True
                    error=''
                    data='登录成功'
                    break
            else:
                raise Exception('\033[41;1m用户名或密码错误\033[0m' %username)
        except Exception as e:
            flag=False
            error=str(e)
            data=''
        return {'flag':flag,'error':error,'data':data}

class School(Base):
    file_path = config.SCHOOL_DIR
    def __init__(self, name, addr):
        self.name = name
        self.addr = addr
        self.id = common.create_id()
        self.create_time = common.format_time()

class Classes(Base):
    file_path=config.CLASS_DIR
    number=0
    def __init__(self,school_id,name,teacher_course_id):
        self.name=name
        self.id=common.create_id()
        self.school_id=school_id
        self.create_time=common.format_time()
        self.teacher_course_id=teacher_course_id
        Classes.number+=1

class Teacher(Base):
    number=0#老师人数
    file_path=config.TEACH_DIR#讲师路经变量
    def __init__(self,name,password,age,sex,salary,school_id):
        self.id=common.create_id()
        self.name=name
        self.password=password
        self.age=age
        self.sex=sex
        self.salary=salary
        self.school_id=school_id
        self.create_time=common.format_time()
        Teacher.number+=1
    @staticmethod
    def login(name,password):
        try:
            for obj in Teacher.open_file_list():
                if obj.name == name and obj.password == password:
                    flag=True
                    error=''
                    file_dir=os.path.join(obj.file_path,str(obj.id))
                    data=file_dir
                    break
            else:
                raise Exception('\033[41;1m用户名或密码错误\033[0m' %name)
        except Exception as e:
            flag=False
            error=str(e)
            data=''
        return {'flag':flag,'error':error,'data':data}

class Course(Base):
    file_path=config.COURSE_DIR
    def __init__(self,name,cycle,price,school_id,):
        self.id=common.create_id()
        self.name=name
        self.cycle=cycle
        self.price=price
        self.school_id=school_id
        self.create_time=common.format_time()

class TeacherCourse(Base):
    file_path=config.TEACHER_COURSE_DIR
    def __init__(self,course_name,teacher_name,school_id):#课程，讲师
        self.id=common.create_id()
        self.name=teacher_name+':'+course_name
        self.course_name=course_name#课程名称
        self.teacher_name=teacher_name#讲师姓名
        self.school_id=school_id#学校ID

class Students(Base):
    file_path=config.STUDENT_DIR
    total=0
    def __init__(self,number,name,password,age,sex,school_id,class_id,phone):
        self.id=common.create_id()
        self.number=number
        self.name=name
        self.password=password
        self.age=age
        self.sex=sex
        self.school_id=school_id
        self.class_id=class_id
        self.phone=phone
        self.score = Score(self.number)
        self.create_time=common.format_time()
        self.tuition=0
    @staticmethod
    def login(name,password):
        try:
            for obj in Students.open_file_list():
                if obj.name == name and obj.password == password:
                    flag=True
                    error=''
                    file_dir=os.path.join(obj.file_path,str(obj.id))
                    data=file_dir
                    break
            else:
                raise Exception('用户名或密码错误' %name)
        except Exception as e:
            flag=False
            error=str(e)
            data=''
        return {'flag':flag,'error':error,'data':data}

class Score():
    def __init__(self,student_id):
        self.student_id=student_id
        self.score_dict={}

    def set(self,teacher_course_id,number):
        self.score_dict[teacher_course_id]=number

    def get(self,teacher_course_id):
        return self.score_dict[teacher_course_id]