#_*_coding:utf-8_*_
'''
teacher
'''
__author__='seagull'

import os
import logging
from  lib.option import *
from  conf.logging_tem import *
logger = logging.getLogger(__name__)





def teacher_info():
    for n in option:
        print(option.index(n),n)
    judge=int(input('请选择：').strip())
    if judge==0:
        student=input('请输入查看的学生：').strip()
        for n in os.walk(PATH_STUDENT):
            if student not in n[2]:
                print('学生不存在')
                teacher_info()
        path=os.path.join(PATH_STUDENT,student)
        with open(path,'r',encoding='utf-8') as f_r:
            print(f_r.read())
        teacher_info()
    elif judge==1:
        print('暂未开放，敬请期待！')
        teacher_info()
    elif judge==2:
        student = input('请输入学生姓名：').strip()
        result=input('请输入学生成绩：').strip()
        for n in os.walk(PATH_STUDENT):
            if student not in n[2]:
                print('学生不存在')
                teacher_info()
        path = os.path.join(PATH_STUDENT, student)
        with open(path, 'a', encoding='utf-8') as f_a:
            f_a.write('\n,{"result":"%s"}'%result)
            teacher_info()
    elif judge==3:
        return 0
    else:
        teacher_info()
















