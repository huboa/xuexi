# -*- coding:utf-8 -*-
import pickle
from prettytable import PrettyTable
from core import common,menu
from modules import Class
def handle_func():
    return {
        'a':student_list,
        'b':select_class,
        'c':score_manager,
    }
def teacher_class_list(teacher_obj):
    class_list = []
    for obj in Class.Classes.open_file_list():
        # print(teacher_obj.name)
        # print(common.id2name(common.id2name(obj.id,obj.file_path).teacher_course_id,Class.TeacherCourse.file_path).teacher_name)
        if teacher_obj.name == common.id2name(common.id2name(obj.id,obj.file_path).teacher_course_id,Class.TeacherCourse.file_path).teacher_name:
            class_list.append(obj)
    # print(class_list)
    return class_list
def student_list(*args):
    teacher_obj = args[0]
    class_list = teacher_class_list(teacher_obj)
    line = PrettyTable(['编号', '班级'])
    line.align = "l"
    line.padding_width = 1
    for k, obj in enumerate(class_list):
        line.add_row([k, obj.name])
    common.printf(line)
    choice = input('请选择要查看的班级编号：').strip()
    select_class_obj = class_list[int(choice)]
    line2 = PrettyTable(['学号', '学员'])
    line2.align = "l"
    line2.padding_width = 1
    for obj in Class.Students.open_file_list():
        if str(common.id2name(obj.class_id,Class.Classes.file_path).name) == str(select_class_obj.name):
            line2.add_row([obj.number,obj.name])
    common.printf(line2)
def select_class(*args):
    teacher_obj = args[0]
    class_list = teacher_class_list(teacher_obj)
    line = PrettyTable(['编号', '班级'])
    line.align = "l"
    line.padding_width = 1
    for k, obj in enumerate(class_list):
        line.add_row([k, obj.name])
    common.printf(line)
    choice = input('请选择要上课的班级编号：').strip()
    select_class_obj = class_list[int(choice)]
    common.printf('%s 老师开始为 %s 班级上课'%(teacher_obj.name,select_class_obj.name))
    end = input('本节课即将结束。。【任意键退出】')
def score_manager(*args):
    teacher_obj = args[0]
    class_list = teacher_class_list(teacher_obj)
    line = PrettyTable(['编号', '班级'])
    line.align = "l"
    line.padding_width = 1
    for k, obj in enumerate(class_list):
        line.add_row([k, obj.name])
    common.printf(line)
    choice = input('请选择要查看的班级编号：').strip()
    select_class_obj = class_list[int(choice)]
    students_list = []
    line = PrettyTable(['编号','学号', '学员'])
    line.align = "l"
    line.padding_width = 1
    for k,obj in enumerate(Class.Students.open_file_list()):
        if str(common.id2name(obj.class_id, Class.Classes.file_path).name) == str(select_class_obj.name):
            students_list.append(obj)
            line.add_row([k,obj.number,obj.name])
    common.printf(line)
    students_name = input('请选择学员编号:').strip()
    students_obj = students_list[int(students_name)]
    for i in students_obj.score.score_dict:
        common.printf('课程：%s 分数：%s' % (i, students_obj.score.score_dict[i]))
    print('请为学员 %s 的 %s 的课程评分' % (
    students_obj.name, common.id2name(common.id2name(students_obj.class_id,Class.Classes.file_path).teacher_course_id,Class.TeacherCourse.file_path).course_name))

    scores = int(input('请输入分数：'))
    students_obj.score.set(common.id2name(common.id2name(students_obj.class_id,Class.Classes.file_path).teacher_course_id,Class.TeacherCourse.file_path).course_name, scores)
    for i in students_obj.score.score_dict:
        common.printf('课程：%s 分数：%s' % (i, students_obj.score.score_dict[i]))
    students_obj.save()
def run():
    while True:
        common.printf(' 讲师登录 '.center(40, '/'), 'correct')
        username = input('用户名[b:返回]：').strip()
        if username == 'b':break
        password = input('密码：').strip()
        user_info = Class.Teacher.login(username,password)
        if user_info['flag']:
            common.printf('登录成功')
            file_path = user_info['data']
            teacher_obj = pickle.load(open(file_path, 'rb'))
            while True:
                menu.teacher_menu(username)
                choice = input('请选择服务编号：').strip()
                if not choice:continue
                if choice == 'd':break
                if choice in handle_func():
                    handle_func()[choice](teacher_obj)
                else:
                    common.printf('服务不存在', 'error')
        else:
            common.printf('用户名或密码错误请重输入','error')