#_*_coding:utf-8_*_
'''

环境变量

os.environ 一个dictionary 包含环境变量的映射关系
os.environ["HOME"] 可以得到环境变量HOME的值
os.chdir(dir) 改变当前目录 os.chdir('d:\\outlook')
注意windows下用到转义
os.getcwd() 得到当前目录
os.getegid() 得到有效组id os.getgid() 得到组id
os.getuid() 得到用户id os.geteuid() 得到有效用户id
os.setegid os.setegid() os.seteuid() os.setuid()
os.getgruops() 得到用户组名称列表
os.getlogin() 得到用户登录名称
os.getenv 得到环境变量
os.putenv 设置环境变量
os.umask 设置umask
os.system(cmd) 利用系统调用，运行cmd命令

'''


import os
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATH_SCHOOL=os.path.join(BASE_DIR,'db','school')
PATH_STUDENT=os.path.join(BASE_DIR,'db','student')
PATH_INFO=os.path.join(BASE_DIR,'db','登陆信息')
PATH_TEACHER=os.path.join(BASE_DIR,'db','teacher')
PATH_COURSE=os.path.join(BASE_DIR,'db','course')
PATH_CLASSES=os.path.join(BASE_DIR,'db','classes')
PATH_SCHOOL_v1=os.path.join(BASE_DIR,'db','school_v1')
PATH_SCHOOL_v2=os.path.join(BASE_DIR,'db','school_v2')




