# -*- coding: utf-8 -*-
# @Author  : ShengLeQi

from core import models
from conf import settings
from core import admin
from core import teacher
import sys,time,os

current_user=[]
dic_student={}
def student_route(name):
    def deco(func):
        dic_student[name]=func
    return deco

#注册
@student_route('1')
def register():
    print('注册')
    name=input('请输入姓名 >')
    age=input('请输入年龄 >')
    student=models.Student(name,age)
    student.save()

    recodes = models.School.get_all(settings.SCHOOL_PATH)
    for i in recodes:
        print('学校名：%s 地址：%s' % (i.name, i.address))
    chice = input('请输入学校编号[ 1、北京 2、上海] >').strip()
    if int(chice)== 1:
        for i in recodes:
            print(i.name)
            if i.name == '北京':
                i.student.append(student)
                i.save()
                print('注册成功.')
    elif int(chice) ==2:
        for i in recodes:
            if i.name == '上海':
                i.student.append(student)
                i.save()
                print('\033[1;42;m  注册成功. \033[0m')

@student_route('2')
def chice_course():
    print('chice-class')
    recoders = models.Course.get_all(settings.COURSE_PATH)
    for course in recoders:
        print('课程名称:%s 价格:%s 周期:%s'%(course.name,course.price,course.period))
    course=input('输入课程名称：>').strip()
    i_course=[course_n.name for course_n in recoders]
    if course in i_course:
        current_user[0].course.append(course)
        current_user[0].save()
        print('\033[1;42;m 选课%s 成功. \033[0m'%current_user[0].course[-1])
    else:print('您输入的课程不存在。')

# #选择班级
@student_route('3')
def chice_class():
    recoders = models.Classes.get_all(settings.CLASSES_PATH)
    for classes in recoders:
        print('课程名称:%s 价格:%s 周期:%s'%(classes.name,classes.semester,classes.date))
    classes=input('输入课程名称：>').strip()
    i_class=[course_n.name for course_n in recoders]
    if classes in i_class:
        current_user[0].classes.append(classes)
        current_user[0].save()
        print('\033[1;42;m 选课%s 成功. \033[0m'%current_user[0].classes[-1])
    else:print('您输入的课程不存在。')

#查看详细信息
@student_route('4')
def show_info():
    # print('查看详细信息')
    print('\033[1;42;m 名字：%s 班级：%s 课程：%s\033[0m'%(current_user[0].name,current_user[0].classes,current_user[0].course))


#查看成绩列表
@student_route('5')
def show_score_lis():
    print('查看成绩列表')

#选择课程
@student_route('6')
def chice_grade():
    print('交学费')

def show_info():
    t_msg = '''
    ----------------------选项--------------------------------
                    1 注册
                    2 选择课程
                    3 选择班级
                    4 查看详细信息
                    5 查看成绩列表
                    6 交学费
                    7 退出
    -----------------------------------------------------------
                    '''
    print(t_msg)

def run():
    msg='''
        欢迎您进入选课系统
        1  学生角色登录
        2  讲师角色登录
        3  管理员角色登录
        4  退出
    '''
    print(msg)
    while True:
        role=input('选择用户登录方式[1.学生|2.讲师|3.管理员| 4.退出] >').strip()
        if not  role.isdigit() or int(role) <1 or int(role)>4:continue
        elif int(role) == 4:break
        if int(role) == 2:
            teacher.run()
        elif int(role) ==3:
            admin.run()
        elif int(role) ==1:
            user_name=input('请输入用户名 >').strip()
            passwd=input('请输入密码 >').strip()
            recoders=models.Student.get_all(settings.STUDENT_PATH)
            for name_s in  recoders:
                if user_name == name_s.name:
                    current_user.append(name_s)
                    while True:
                        show_info()
                        chice = input('选择 >').strip()
                        if chice.isdigit() and int(chice) > 0 and int(chice) < 7:
                            dic_student[chice]()
                        elif chice.isdigit() and int(chice) == 7:
                            break
            else:
                print('此用户不存在.')
                chice=input('是否开始注册[1、开始注册 2、退出]').strip()
                if int(chice) ==1:
                    dic_student['1']()
                else:break








