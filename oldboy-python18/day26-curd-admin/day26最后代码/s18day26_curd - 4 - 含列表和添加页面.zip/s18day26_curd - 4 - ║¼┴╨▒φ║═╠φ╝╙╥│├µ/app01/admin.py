from django.contrib import admin
#
# # Register your models here.
# print('admin.py执行')